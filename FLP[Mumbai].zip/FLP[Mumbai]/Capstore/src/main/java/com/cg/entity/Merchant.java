package com.cg.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "capstore_merchants")
public class Merchant {
	@Id
	@GeneratedValue
	int merchantId;
	@Column(length = 20)
	String merchantType;
	@Column( length = 20)
	String merchantName;
	@Column( length = 10)
	String merchantPhone;
	@Column(unique = true , length = 30)
	String merchantEmail;
	@Column( length = 12)
	String merchantAadhar;
	@Column( length = 20)
	String merchantPassword;
	@Column(length = 50)
	String merchantAddress;
	
	public String getType() {
		return merchantType;
	}
	public void setType(String type) {
		this.merchantType = type;
	}
	public int getMerchantId() {
		return merchantId;
	}
	public void setMerchantId(int merchantId) {
		this.merchantId = merchantId;
	}
	public String getMerchantType() {
		return merchantType;
	}
	public void setMerchantType(String merchantType) {
		this.merchantType = merchantType;
	}
	public String getMerchantName() {
		return merchantName;
	}
	public void setMerchantName(String merchantName) {
		this.merchantName = merchantName;
	}
	public String getMerchantPhone() {
		return merchantPhone;
	}
	public void setMerchantPhone(String merchant_Phone) {
		this.merchantPhone = merchant_Phone;
	}
	public String getMerchantEmail() {
		return merchantEmail;
	}
	public void setMerchantEmail(String merchantEmail) {
		this.merchantEmail = merchantEmail;
	}
	public String getMerchantAadhar() {
		return merchantAadhar;
	}
	public void setMerchantAadhar(String merchantAadhar) {
		this.merchantAadhar = merchantAadhar;
	}
	public String getMerchantPassword() {
		return merchantPassword;
	}
	public void setMerchantPassword(String merchantPassword) {
		this.merchantPassword = merchantPassword;
	}
	public String getMerchantAddress() {
		return merchantAddress;
	}
	public void setMerchantAddress(String merchantAddress) {
		this.merchantAddress = merchantAddress;
	}
}
