package com.cg.entity;

import javax.annotation.Generated;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "feedbacks")
public class Feedback {

	@Id
	@GeneratedValue
	private int feedbackId;
	
	@Column(name = "product_name",length = 15)
	private String name;
	
	@Column(name = "stars",length = 15)
	private int stars;
	
	@Column(name = "comments",length = 100)
	private String comments;
	
	
	
	@Column(name = "Product_id",length = 15)
	private int prodId;
	

	public Feedback(String name, int stars, String comments, int prodId) {
		super();
		this.name = name;
		this.stars = stars;
		this.comments = comments;
		this.prodId = prodId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Feedback() {
		// TODO Auto-generated constructor stub
	}

	public int getProdId() {
		return prodId;
	}

	public void setProdId(int prodId) {
		this.prodId = prodId;
	}


	public int getStars() {
		return stars;
	}
	

	public int getFeedbackId() {
		return feedbackId;
	}

	public void setFeedbackId(int feedbackId) {
		this.feedbackId = feedbackId;
	}

	public void setStars(int stars) {
		this.stars = stars;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}


	
	@Override
	public String toString() {
		return "Feedback [feedbackId=" + feedbackId + ", name=" + name + ", stars=" + stars + ", comments=" + comments
				+ ", prod=" + ", prodId=" + prodId + "]";
	}


	
	
	
	
}

