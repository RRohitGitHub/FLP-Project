package com.cg.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.entity.Product;

public interface Capg_Search_Repo extends JpaRepository<Product, Integer>{

	@Query("from Product where name=:na")
	public List<Product> getProductByName(@Param("na")String name);
	
	@Query("from Product where brand=:br")
	public List<Product> getProductByBrand(@Param("br")String brand);
	
	@Query("from Product where category=:ca")
	public List<Product> getProductByCategory(@Param("ca")String category);
	
	@Query("from Product ORDER BY price ASC")
	public List<Product> findAllProductsByPriceAsc();
	
	@Query("from Product ORDER BY price DESC")
	public List<Product> findAllProductsByPriceDesc();
	
	@Query("from Product ORDER BY id DESC")
	public List<Product> findAllProductsByNewest();
	
	@Query("from Product where price>=999")
	public List<Product> findAllProductsByPrice();
}
