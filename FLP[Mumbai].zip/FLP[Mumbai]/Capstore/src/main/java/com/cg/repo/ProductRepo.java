package com.cg.repo;

import java.util.List;

import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.entity.Product;



public interface ProductRepo extends JpaRepository<Product, Integer> {

	// Merchant Home page Methods
	@Query("from Product where name=:nm and merchantId=:mid")
	List<Product> searchByName(@Param("nm") String nm,@Param("mid")int mid);
	
	@Query("from Product where brand=:bd and merchantId=:mid")
	List<Product> searchByBrand(@Param("bd") String bd,@Param("mid")int mid);
	
	@Query("from Product where category=:cat and merchantId=:mid")
	List<Product> searchByCategory(@Param("cat") String cat,@Param("mid")int mid);
	
	// methods to be provided to customer
	@Query("from Product ORDER BY price ASC")
	List<Product> findAllProductsByPriceAsc(Sort sort);

	@Query("from Product ORDER BY price DESC")
	List<Product> findAllProductsPriceDsc(Sort sort);

	@Query("from Product ORDER BY id DESC")
	List<Product> findAllProductsNewest();

	@Query("from Product where price>=999")
	List<Product> findAllProductsByPrice();
	
	@Query("from Product where merchantId=:mid")
	List<Product> getProductByMerchid(@Param("mid")int mid);
	
	@Query("from Product where id=:proId")
	public Product getProductById(@Param("proId") int proId);

}
