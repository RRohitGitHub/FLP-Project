package com.cg.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.entity.Cartlist;
import com.cg.entity.CustomerOrderBean;

public interface GenerateInvoiceRepo extends JpaRepository<Cartlist, Integer>{
	
	@Query("from Cartlist where custId=:c_id")
	public List<Cartlist> getInvoiceById(@Param("c_id") int c_id);
	
	

}

