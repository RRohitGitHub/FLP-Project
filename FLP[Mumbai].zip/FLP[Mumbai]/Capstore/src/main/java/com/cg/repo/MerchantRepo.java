package com.cg.repo;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.cg.entity.Merchant;

@Repository
public interface MerchantRepo extends JpaRepository<Merchant, Integer> {

	@Query("SELECT merchantEmail FROM Merchant")
	List<String>emails();
	
	@Query("from Merchant where merchantEmail=:email")
	public Merchant findByName(@Param("email") String email);
	
	@Query("SELECT merchantPassword FROM Merchant")
	public List<String> findByPassword();
	
	
	
}
