package com.cg.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "capstore_product")
@SequenceGenerator(name = "seq", initialValue = 101, allocationSize = 100)
public class Product {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq")
	@Column(name = "product_id")
	private int id;

	@Column(name = "product_name", length = 15)
	private String name;

	@Column(name = "price", length = 15)
	private int price;

	@Column(name = "discount", length = 15)
	private double discount;

	@Column(name = "brand", length = 15)
	private String brand;

	@Column(name = "stock", length = 15)
	private int stock;

	@Column(name = "category", length = 15)
	private String category;

	@Column(name = "sub_category", length = 15)
	private String subCategory;

	@Column(name = "vote_count", length = 15)
	private int voteCount;

	@Column(name = "prev_vote_sum", length = 15)
	private int prevVoteSum;

	@Column(name = "avg_rating", length = 15)
	private double avgRating;

	@Column(name = "sold_stock")
	private int soldStock;

	@Column(name = "merchant_id")
	private int merchantId;

	// Constructor
	public Product() {
	}

	// Parameterized Constructor
	public Product(String productName, int price, double discount, String brand, int stock, String category,
			String subCategory, int voteCount, int prevVoteSum, double avgRating, int soldStock, int merchantId) {
		this.name = productName;
		this.price = price;
		this.discount = discount;
		this.brand = brand;
		this.stock = stock;
		this.category = category;
		this.subCategory = subCategory;
		this.voteCount = voteCount;
		this.prevVoteSum = prevVoteSum;
		this.avgRating = avgRating;
		this.soldStock = soldStock;
		this.merchantId = merchantId;
	}

	// Getter-Setter

	public int getProductId() {
		return id;
	}

	public void setProductId(int productId) {
		this.id = productId;
	}

	public String getProductName() {
		return name;
	}

	public void setProductName(String productName) {
		this.name = productName;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public double getDiscount() {
		return discount;
	}

	public void setDiscount(double discount) {
		this.discount = discount;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public int getStock() {
		return stock;
	}

	public void setStock(int stock) {
		this.stock = stock;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getSubCategory() {
		return subCategory;
	}

	public void setSubCategory(String subCategory) {
		this.subCategory = subCategory;
	}

	public int getVoteCount() {
		return voteCount;
	}

	public void setVoteCount(int voteCount) {
		this.voteCount = voteCount;
	}

	public int getPrevVoteSum() {
		return prevVoteSum;
	}

	public void setPrevVoteSum(int prevVoteSum) {
		this.prevVoteSum = prevVoteSum;
	}

	public double getAvgRating() {
		return avgRating;
	}

	public void setAvgRating(double avgRating) {
		this.avgRating = avgRating;
	}

	public int getSoldStock() {
		return soldStock;
	}

	public void setSoldStock(int soldStock) {
		this.soldStock = soldStock;
	}

	public int getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(int merchantId) {
		this.merchantId = merchantId;
	}

	@Override
	public String toString() {
		return "Product [productId=" + id + ", productName=" + name + ", price=" + price + ", discount="
				+ discount + ", brand=" + brand + ", stock=" + stock + ", category=" + category + ", subCategory="
				+ subCategory + ", voteCount=" + voteCount + ", prevVoteSum=" + prevVoteSum + ", avgRating=" + avgRating
				+ ", soldStock=" + soldStock + ", merchantId=" + merchantId + "]";
	}

}
