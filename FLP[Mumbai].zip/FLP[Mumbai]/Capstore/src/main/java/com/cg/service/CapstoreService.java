package com.cg.service;

import java.util.List;


import com.cg.entity.Cartlist;
import com.cg.entity.Customer;
import com.cg.entity.CustomerOrderBean;
import com.cg.entity.DeliveryDetailsBean;
import com.cg.entity.Feedback;
import com.cg.entity.Merchant;
import com.cg.entity.Product;
import com.cg.entity.ShippingDetailsBean;
import com.cg.entity.WishList;

public interface CapstoreService {

	public void addMerchant(Merchant cus);
	public List<String> existCustomer();
	public List<String> getPasswords();
	public void addCustomer(Customer capstore);
	public List<String> existMerchant();
	public List<String> customerPassword();
	public List<Customer> searchAllCustomers();
	public Customer updateCustomer(Customer cdb, int id);
	public Customer findById(int id);
	Customer getCustomerById(int id);
	void deleteCustomer(int id);
	Merchant getMerchantById(int id);
	void deleteMerchant(int id);
	List<Merchant> getAllMerchants();
	Merchant updateMerchant(int id, Merchant ce);
	Merchant getByUsername(String username);
	
	/*
	 * Merchant services......
	 */
	
	boolean saveProduct(Product prod);
	
	List<Product> displayAllByPriceAsc();
	
	List<Product> displayAllByPriceDsc();
	
	List<Product> displayAllByNewest();
	
	List<Product> displayByPrice();
	
	Product updateProduct(Product prod);

	//List<Product> getAll();

	Product getProdById(int id);

	List<Product> searchByName(String name,int mid);

	List<Product> searchByBrand(String brand,int mid);

	List<Product> searchByCategory(String cat,int mid);

	boolean deleteByProductId(int id);

	List<Product> getAllProductsByMerchId(int id);
	
	Feedback saveFeedback(Feedback f);

	List<Feedback> getTopFeedback(int pid);
	
	
	/*
	 * Customer Methods.....
	 */
	

	public void setDetails(ShippingDetailsBean shipDetails,int cust_id);

	public List<ShippingDetailsBean> showdetails(int cust_id);
	
	
	

	public List<DeliveryDetailsBean> returnGood(int d_Id);

	public List<DeliveryDetailsBean> getById(int d_id);

	public List<DeliveryDetailsBean> getAll();

	public  List<Cartlist> generateInvoice(int orderId);
	

	public void saveDelivery(DeliveryDetailsBean delBean);
	
	
	/*
	 * customer method part 2
	 * 
	 */
	
	public Product searchById(int id);
	List<Product> getProductByName(String name);
	List<Product> getProductByBrand(String brand);
	List<Product> getProductByCategory(String category);
	
	void addtoWishList(WishList wishlist);
	List<WishList> getWishProducts(int cust_Id);
	List<WishList> deletewish(int wishId);
	
	boolean addToCart(Cartlist cart);
	List<Cartlist> getAll(int cust_id);
	boolean deletecart(int prod_id);
	
	public Customer getCustomer(int cust_id);
	public Customer updateCustomer(Customer c);
	
	public Cartlist getcart(Product p,int cust_id,int quantity);
	public WishList getwish(Product p, int cust_id);
	
	public double buynow(int pro_id, int qty);
	public List<Cartlist> getAllCart(int cust_id);
	public List<Cartlist> getFinal(int custID);
	public Customer throwCustomer(String email);
	
	
	public void createCustomerOrder(CustomerOrderBean custorder );
	public void createDelivery(DeliveryDetailsBean deli);
	public boolean updateProductAtEnd(List<Product> pro, int pro_id);
	



	


	
	

}
