package com.cg.entity;

import java.util.Date;

import javax.persistence.*;

@Entity
@Table(name="customer_order")
public class CustomerOrderBean {
	@Id
	@GeneratedValue(generator="cust_seq")
	private int orderId;
	
	@Column(name="pro_id")
	private int proId;
	
	@Column(length=30)
	private String proName;
	
	@Column(length=30)
	private double price;
	
	
	@Temporal(TemporalType.DATE)
	@Column(length=20)
	private Date orderDate;
	
	@Column(length=20)
	private String paymentMode;
	
	@Column(length=20)
	private String deliveredAddress;
	
	@Column(length=10)
	private int customerId;
	
	
	@Column(length=10)
	private int quantity;
	
	
	@Column(name="merchant_id")
	private int merchantId;
	
	public CustomerOrderBean() {
		// TODO Auto-generated constructor stub
	}

	
	


	public CustomerOrderBean(int orderId, int proId, String proName, double price, Date orderDate, String paymentMode,
			String deliveredAddress, int customerId, int quantity, int merchantId) {
		super();
		this.orderId = orderId;
		this.proId = proId;
		this.proName = proName;
		this.price = price;
		this.orderDate = orderDate;
		this.paymentMode = paymentMode;
		this.deliveredAddress = deliveredAddress;
		this.customerId = customerId;
		this.quantity = quantity;
		this.merchantId = merchantId;
	}





	public int getOrderId() {
		return orderId;
	}


	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}


	public int getProId() {
		return proId;
	}


	public void setProId(int proId) {
		this.proId = proId;
	}


	public String getProName() {
		return proName;
	}


	public void setProName(String proName) {
		this.proName = proName;
	}


	public double getPrice() {
		return price;
	}


	public void setPrice(double price) {
		this.price = price;
	}


	public Date getOrderDate() {
		return orderDate;
	}


	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}


	public String getPaymentMode() {
		return paymentMode;
	}


	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}


	public String getDeliveredAddress() {
		return deliveredAddress;
	}


	public void setDeliveredAddress(String deliveredAddress) {
		this.deliveredAddress = deliveredAddress;
	}


	public int getCustomerId() {
		return customerId;
	}


	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}


	public int getQuantity() {
		return quantity;
	}


	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}


	public int getMerchantId() {
		return merchantId;
	}


	public void setMerchantId(int merchantId) {
		this.merchantId = merchantId;
	}


	@Override
	public String toString() {
		return "CustomerOrderBean [orderId=" + orderId + ", proId=" + proId + ", proName=" + proName + ", price="
				+ price + ", orderDate=" + orderDate + ", paymentMode=" + paymentMode + ", deliveredAddress="
				+ deliveredAddress + ", customerId=" + customerId + ", quantity=" + quantity + ", merchantId="
				+ merchantId + "]";
	}


	
	

	
	
	
	

}
