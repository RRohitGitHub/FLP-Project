package com.cg.entity;

import java.time.LocalDate;
import java.util.Date;

import javax.persistence.*;

@Entity
@Table(name="delivery_details")
public class DeliveryDetailsBean {
	@Id
	@GeneratedValue(generator="del_seq")
	private int dId;
	
	
	@Column(name="customer_id")
	private int customerId;
	

	@Column(name="pro_id")
	private int proId;
	
	@Column(length=30)
	private String proName;
	
	@Column(length=10)
	private double price;
	
	@Column(length=20)
	private String status;
	
	@Column(length=20)
	private LocalDate orderDate;
	

	@Column(name="quantity")
	private int quantity;
	
	@Column(name="merchant_id")
	private int merchantId;
	
	
	@Column(length=20)
	private String deliveredAddress;
	
	public DeliveryDetailsBean() {
		// TODO Auto-generated constructor stub
	}

	
	public DeliveryDetailsBean(int dId, int customerId, int proId, String proName, double price, String status,
			LocalDate orderDate, int quantity, int merchantId, String deliveredAddress) {
		super();
		this.dId = dId;
		this.customerId = customerId;
		this.proId = proId;
		this.proName = proName;
		this.price = price;
		this.status = status;
		this.orderDate = orderDate;
		this.quantity = quantity;
		this.merchantId = merchantId;
		this.deliveredAddress = deliveredAddress;
	}


	public int getdId() {
		return dId;
	}

	public void setdId(int dId) {
		this.dId = dId;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public int getProId() {
		return proId;
	}

	public void setProId(int proId) {
		this.proId = proId;
	}

	public String getProName() {
		return proName;
	}

	public void setProName(String proName) {
		this.proName = proName;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public LocalDate getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(LocalDate orderDate) {
		this.orderDate = orderDate;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public int getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(int merchantId) {
		this.merchantId = merchantId;
	}

	public String getDeliveredAddress() {
		return deliveredAddress;
	}

	public void setDeliveredAddress(String deliveredAddress) {
		this.deliveredAddress = deliveredAddress;
	}

	@Override
	public String toString() {
		return "DeliveryDetailsBean [dId=" + dId + ", customerId=" + customerId + ", proId=" + proId + ", proName="
				+ proName + ", price=" + price + ", status=" + status + ", orderDate=" + orderDate + ", quantity="
				+ quantity + ", merchantId=" + merchantId + ", deliveredAddress=" + deliveredAddress + "]";
	}



	


	
	
	
	

}
