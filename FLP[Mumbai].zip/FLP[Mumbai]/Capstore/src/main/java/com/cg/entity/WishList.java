package com.cg.entity;



import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


@Entity
@Table(name = "wish_list1")
public class WishList {
	
	@Id
	@GeneratedValue
	private int wishId;
	
	@ManyToOne
	@JoinColumn(name = "id", nullable = false)
	private Product product;
	
	
	private int customerId;
     public WishList() {
	// TODO Auto-generated constructor stub
}
	
	
	public WishList(Product product, int customerId) {
		this.product = product;
		this.customerId = customerId;
	}
	public int getWishId() {
		return wishId;
	}
	public void setWishId(int wishId) {
		this.wishId = wishId;
	}
	
	public Product getProduct() {
		return product;
	}
	public void setProduct(Product product) {
		this.product = product;
	}
	
	public int getCustomerId() {
		return customerId;
	}


	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}


	@Override
	public String toString() {
		return "WishList [wishId=" + wishId + ", product=" + product + ", cust_id=" + customerId + "]";
	}
	
	
	
	
	

}
