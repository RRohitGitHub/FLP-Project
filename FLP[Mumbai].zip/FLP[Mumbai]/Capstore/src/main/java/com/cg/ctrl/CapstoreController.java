package com.cg.ctrl;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entity.Cartlist;
import com.cg.entity.Customer;
import com.cg.entity.CustomerOrderBean;
import com.cg.entity.DeliveryDetailsBean;
import com.cg.entity.Feedback;
import com.cg.entity.Merchant;
import com.cg.entity.Product;
import com.cg.entity.ShippingDetailsBean;
import com.cg.entity.WishList;
import com.cg.service.CapstoreService;

@RestController
@RequestMapping(value = "/capstore")
@CrossOrigin(origins = "http://localhost:4200")
public class CapstoreController {

	@Autowired
	private CapstoreService service;

	@PostMapping(value = "/add", consumes = "application/json")
	Merchant addMerchant(@RequestBody Merchant mer) {
		service.addMerchant(mer);
		return mer;
	}

	@GetMapping(value = "/exists", produces = "application/json")
	List<String> getUser() {
		return service.getPasswords();
	}

	@GetMapping(value = "/exist", produces = "application/json")
	List<String> getEmail() {
		return service.existMerchant();
	}

	@GetMapping(value = "/customerEmail", produces = "application/json")
	List<String> getCustomerEmail() {
		return service.existCustomer();
	}

	@GetMapping(value = "/getMerchant/{username}", produces = "application/json")
	Merchant getCustomerEmail(@PathVariable("username") String userName) {
		return service.getByUsername(userName);
	}

	@PostMapping(value = "/customerAdd", consumes = "application/json")
	Customer addCustomer(@RequestBody Customer cus) {
		service.addCustomer(cus);
		return cus;
	}

	@GetMapping(value = "/customerPassword", produces = "application/json")
	List<String> getCustomerPassword() {
		return service.customerPassword();
	}

	@GetMapping(value = "/findAllCustomers", produces = "application/json")
	public List<Customer> findAllCustomers() {
		System.out.println(service.searchAllCustomers());
		return service.searchAllCustomers();
	}

	@PutMapping(value = "/updateCustomer/{id}", consumes = "application/json", produces = "application/json")
	public Customer updateCustomer(@RequestBody Customer cdb, @PathVariable("id") int id) {
		return service.updateCustomer(cdb, id);

	}

	@GetMapping(value = "/findCustomerById/{id}", produces = "application/json")
	public Customer findCustomerById(@PathVariable("id") int id) {
		System.out.println(service.findById(id));
		return service.findById(id);
	}

	@DeleteMapping(value = "/customer/delete/{id}", produces = "application/json")
	public String deleteCustomer(@PathVariable("id") int id) {
		service.deleteCustomer(id);
		return "Customer deleted";
	}

	@GetMapping(value = "/find/{id}", produces = "application/json")
	public Merchant findById(@PathVariable("id") int id, Merchant ce) {
		return service.getMerchantById(id);
	}

	@GetMapping(value = "/findall", produces = "application/json")
	public List<Merchant> findAll() {
		return service.getAllMerchants();
	}

	@DeleteMapping(value = "/delete/{id}")
	public void delete(@PathVariable("id") int id, Merchant ce) {
		service.deleteMerchant(id);
	}

	@PutMapping(value = "/update/{id}", produces = "application/json", consumes = "application/json")
	public Merchant update(@PathVariable("id") int id, @RequestBody Merchant ce) {
		return service.updateMerchant(id, ce);
	}

	/*
	 * 
	 * Merchants Controller
	 * 
	 */

	// Save updated product object
	@PutMapping(value = "merchant/update")
	public Product updateProduct(@RequestBody Product product) {
		System.out.println(product);
		service.updateProduct(product);
		return product;
	}

	// addProduct
	@PostMapping(value = "merchant/create")
	public Product addProduct(@RequestBody Product prod) {
		System.out.println(prod.getProductName());
		System.out.println(prod);
		service.saveProduct(prod);
		return prod;
	}

	// searchByName
	@GetMapping(value = "merchant/getProdByName/{name}/{mid}")
	public List<Product> searchByName(@PathVariable("name") String name, @PathVariable("mid") int mid) {
		return service.searchByName(name, mid);
	}

	// searchByName
	@GetMapping(value = "merchant/getProdByBrand/{brand}/{mid}")
	public List<Product> searchByBrand(@PathVariable("brand") String brand, @PathVariable("mid") int mid) {
		System.out.println(brand);
		List<Product> p = new ArrayList<Product>();
		p = service.searchByBrand(brand, mid);
		/*
		 * for (Product product : p) { System.out.println(product); }
		 */
		return p;
	}

	// searchByName
	@GetMapping(value = "merchant/getProdByCategory/{cat}/{mid}")
	public List<Product> searchByCategory(@PathVariable("cat") String cat, @PathVariable("mid") int mid) {
		return service.searchByCategory(cat, mid);
	}

	// Fetch Product at click of EDIT button
	@GetMapping(value = "merchant/getProdById/{id}")
	public Product getProdById(@PathVariable("id") int id) {
		return service.getProdById(id);
	}

	// showProducts
	/*
	 * @GetMapping(value="merchant/getAllProducts") public List<Product>
	 * getAllProducts() { return service.getAll(); }
	 */

	@GetMapping(value = "merchant/productasc")
	public List<Product> viewALLProducts() {
		return service.displayAllByPriceAsc();
	}

	@GetMapping(value = "merchant/productdsc")
	public List<Product> viewALLProducts2() {
		return service.displayAllByPriceDsc();
	}

	@GetMapping(value = "merchant/productnew")
	public List<Product> viewALLProducts3() {
		return service.displayAllByNewest();
	}

	@GetMapping(value = "merchant/productprice")
	public List<Product> viewALLProducts4() {
		return service.displayByPrice();
	}

	@GetMapping(value = "merchant/delete/{id}")
	public boolean deleteByProductId(@PathVariable("id") int id) {
		System.out.println(id);
		return service.deleteByProductId(id);
	}

	@GetMapping(value = "merchant/getAllProductsByMerchId/{id}")
	public List<Product> getProductByMerchId(@PathVariable("id") int id) {
		return service.getAllProductsByMerchId(id);
	}

	@PostMapping(value = "merchant/storeFeedback", produces = "application/json")
	public Feedback storeFeedback(@RequestBody Feedback f) {

		System.out.println(f);
		return service.saveFeedback(f);
	}

	@GetMapping(value = "merchant/getAllFeedback/{id}", produces = "application/json")
	public List<Feedback> getAllFeedback(@PathVariable("id") int id) {
		return service.getTopFeedback(id);
	}

	/*
	 * Customer Controller
	 */

	@GetMapping(value = "/product/{id}", produces = "application/json")
	public Product getProductById(@PathVariable("id") int id) {
		return service.searchById(id);
	}

	@GetMapping(value = "/product/name/{na}", produces = "application/json")
	public List<Product> searchProductByName(@PathVariable("na") String na) {
		return service.getProductByName(na);
	}

	@GetMapping(value = "/product/brand/{br}", produces = "application/json")
	public List<Product> searchProductByBrand(@PathVariable("br") String br) {
		return service.getProductByBrand(br);
	}

	@GetMapping(value = "/product/category/{ca}", produces = "application/json")
	public List<Product> searchProductByCategory(@PathVariable("ca") String ca) {
		return service.getProductByCategory(ca);
	}

	@PostMapping(value = "/addtowishlist/{custId}", consumes = "application/json")
	public void addtoWishList(@PathVariable int custId, @RequestBody Product p) {
		WishList wishlist = service.getwish(p, custId);
		service.addtoWishList(wishlist);
	}

	@PostMapping(value = "/cart/add/{cust_id}/{quantity}", consumes = "application/json")
	public String addCart(@PathVariable("cust_id") int cust_id, @PathVariable("quantity") int quantity,
			@RequestBody Product p) {
		Cartlist c = service.getcart(p, cust_id, quantity);
		service.addToCart(c);
		return "Product saved successfullly.";
	}

	@GetMapping(value = "/getwishlist/{custid}", produces = "application/json")
	public List<WishList> getWishItemById(@PathVariable("custid") int custid) {
		System.out.println(custid);
		return service.getWishProducts(custid);
	}

	@DeleteMapping(value = "/deletewish/{wishId}", produces = "application/json")
	public List<WishList> deletewish(@PathVariable int wishId) {

		System.out.println("successfully deleted");
		return service.deletewish(wishId);
	}

//		@PostMapping(value = "/add", consumes = "application/json")
//		public String addCart(@RequestBody Cartlist cart) {
//		 service1.addToCart(cart);
//				return "Product saved successfullly.";
//		}
	//
	//
//		@GetMapping(value = "/cart/{custId}", produces = "application/json")
//		public List<Cartlist> getAllCarts(@PathVariable("custId")int custId) {
//			return service1.getAll(custId);
//		}

	@DeleteMapping(value = "/CartItemDelete/{cartId}", produces = "application/json")
	public void deleteCartItemtById(@PathVariable("cartId") int cartId) {
		service.deletecart(cartId);
	}

	@GetMapping(value = "/getCustomer/{cust_id}", produces = "application/json")
	public Customer getCustomer(@PathVariable int cust_id) {
		return service.getCustomer(cust_id);
	}

	@PutMapping(value = "/updateProfile/{cust_id}")
	public boolean updateCustomer(@PathVariable int cust_id, @RequestBody Customer updatedCustomer) {
		Customer c = service.getCustomer(cust_id);
		c.setCustomerName(updatedCustomer.getCustomerName());
		service.updateCustomer(updatedCustomer);
		return true;
	}

	@GetMapping(value = "/final/{cid}", produces = "application/json")
	public List<Cartlist> finalPrice(@PathVariable("cid") int cid) {
		return service.getFinal(cid);
	}

	@GetMapping(value = "/buy/{pro_id}/{qty}", produces = "application/json")
	public double buy(@PathVariable("pro_id") int pro_id, @PathVariable("qty") int qty) {
		return service.buynow(pro_id, qty);
	}

	@GetMapping(value = "/pro/{id}", produces = "application/json")
	public Product getProById(@PathVariable("id") int id) {
		return service.getProdById(id);
	}

//get by Riya
	@GetMapping("/invoiceGenerated/{custId}")
	public List<Cartlist> generateInvoice(@PathVariable("custId") int custId) {
	
		return service.generateInvoice(custId);
	}

	@GetMapping("/getlist")
	public List<DeliveryDetailsBean> getAll() {
		return service.getAll();
	}

	@GetMapping("/get/{d_id}")
	public List<DeliveryDetailsBean> getById(@PathVariable("d_id") int d_id) {
		return service.getById(d_id);
	}

	@PutMapping("/return/{d_Id}")
	public List<DeliveryDetailsBean> returnGood(@PathVariable("d_Id") int d_Id) {
		return service.returnGood(d_Id);

	}

//get Abhimanyu
	@PostMapping(value = "/shippingdetails/{custid}", consumes = "application/json")
	public String setDetails(@RequestBody ShippingDetailsBean shipDetails, @PathVariable("custid") int custid) {
		service.setDetails(shipDetails, custid);

		return "saved Successfully";
	}

	@GetMapping(value = "/showdetails/{cust_id}", produces = "application/json")
	public List<ShippingDetailsBean> showDetails(@PathVariable("cust_id") int cust_id) {
		return service.showdetails(cust_id);
	}

//get Rohita
	@PostMapping(value = "/deliver", consumes = "application/json")
	public void saveDelivery(@RequestBody DeliveryDetailsBean delDelivery) {

		service.saveDelivery(delDelivery);
	}

	@PutMapping(value = "/placeOrder/{pro_id}", consumes = "application/json", produces = "application/json")
	public String updateProduct( @PathVariable int pro_id,@RequestBody List<Product> pro) {
		/*
		 * if (service.updateProductAtEnd(order_id, pro_id)) return "Stock is updated";
		 * else return "Stock is not updated";
		 */
		service.updateProductAtEnd(pro, pro_id);
		
		return "";
	}

	@GetMapping(value = "/throwCustomer/{email}", produces = "application/json")
	public Customer throwCustomer(@PathVariable("email") String email) {
		System.out.println(service.throwCustomer(email));
		return service.throwCustomer(email);
	}

	@PostMapping(value = "/createcustomerorder", consumes = "application/json")
	public void createCustomerOrder(@RequestBody CustomerOrderBean custorder) {
		service.createCustomerOrder(custorder);
	}

	@PostMapping(value = "/setdelivery", consumes = "application/json")
	public void createDelivery(@RequestBody DeliveryDetailsBean deli) {
		service.createDelivery(deli);

	}

}
