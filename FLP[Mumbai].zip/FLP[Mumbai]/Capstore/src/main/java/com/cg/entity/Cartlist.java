package com.cg.entity;

import javax.persistence.*;

@Entity
@Table(name = "capstore_cartlist2")
public class Cartlist {

	@Id
	@GeneratedValue
	private int cartId;
	private int custId;

	@ManyToOne
	@JoinColumn(name = "id", nullable = false)
	private Product proId;

	private double tprice;
	private int quantity;
	private double finalprice;

	public Cartlist() {
		// TODO Auto-generated constructor stub
	}

	public Cartlist(int custId, Product proId, double tprice, int quantity) {
		this.custId = custId;
		this.proId = proId;
		this.tprice = tprice;
		this.quantity = quantity;
	}

	public int getCartId() {
		return cartId;
	}

	public void setCartId(int cartId) {
		this.cartId = cartId;
	}

	public int getCustId() {
		return custId;
	}

	public void setCustId(int custId) {
		this.custId = custId;
	}

	public Product getProId() {
		return proId;
	}

	public void setProId(Product proId) {
		this.proId = proId;
	}

	public double getTprice() {
		return tprice;
	}

	public void setTprice(double tprice) {
		this.tprice = tprice;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public double getFinalprice() {
		return finalprice;
	}

	public void setFinalprice(double finalprice) {
		this.finalprice = finalprice;
	}

	
	

	
}
