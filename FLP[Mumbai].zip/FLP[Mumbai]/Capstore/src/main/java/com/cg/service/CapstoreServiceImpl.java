package com.cg.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Base64.Decoder;
import java.util.Base64.Encoder;
import java.util.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


import com.cg.entity.Cartlist;
import com.cg.entity.Coupon;
import com.cg.entity.Customer;
import com.cg.entity.CustomerOrderBean;
import com.cg.entity.DeliveryDetailsBean;
import com.cg.entity.Feedback;
import com.cg.entity.Merchant;
import com.cg.entity.Product;
import com.cg.entity.ShippingDetailsBean;
import com.cg.entity.WishList;
import com.cg.repo.Capg_Search_Repo;
import com.cg.repo.CapstoreRepo;
import com.cg.repo.CartlistRepo;
import com.cg.repo.CouponRepo;
import com.cg.repo.CustomerOrderRepo;

import com.cg.repo.DeliveryRepo;
import com.cg.repo.FeedbackRepo;
import com.cg.repo.GenerateInvoiceRepo;
import com.cg.repo.MerchantRepo;
import com.cg.repo.ProductRepo;
import com.cg.repo.ShippingRepo;
import com.cg.repo.WishListRepo;

@Service
@Transactional
public class CapstoreServiceImpl implements CapstoreService {
	
	@Autowired
	MerchantRepo repo;
	@Autowired
	public JavaMailSender javaMailSender;
	@Autowired
	public CapstoreRepo customerRepo;

	@Autowired
	private ProductRepo pRepo;

	@Autowired
	FeedbackRepo fRepo;
	
	
	@Autowired
	private ShippingRepo shipRepo;

//	@Autowired
//	private CartList cartRepo;
	@Autowired
	private GenerateInvoiceRepo invoiceRepo;

	@Autowired
	private DeliveryRepo delRepo;


	@Autowired
	private CustomerOrderRepo oRepo;

	@Autowired
	private CartlistRepo crepo;
	

	@Autowired
	private CouponRepo couponRepo;
	
	@Autowired
	private Capg_Search_Repo customerSearchRepo;
	
	@Autowired 
	WishListRepo wishRepo;
	
	@Autowired 
	CartlistRepo cartRepo;
	
	
	
	
//	Customer Add
	@Override
	public void addCustomer(Customer capstore) {
		String p1 = capstore.getCustomerPassword();
		java.util.Base64.Encoder encoder = Base64.getEncoder();
		String encodedPassword1 = encoder.encodeToString(p1.getBytes());
		capstore.setCustomerPassword(encodedPassword1);
		customerRepo.save(capstore);
//		if (!repo.emails().contains(capstore.getCustomerEmail())) {
			String s = "Congratulations!!!! You are a part of Capstore";
			sendEmail(capstore.getCustomerEmail(), s);

//		}
	}

// Merchant Add
	@Override
	public void addMerchant(Merchant mer) {

		Encoder encode = Base64.getEncoder();
		String encoded = encode.encodeToString(mer.getMerchantPassword().getBytes());
		mer.setMerchantPassword(encoded);

		repo.save(mer);
//		if (!repo.emails().contains(mer.getMerchantEmail())) {
			String s = "Congratulations!!!! You are a part of Capstore";
			sendEmail(mer.getMerchantEmail(), s);

//		}
	}

//	 Merchant Email
	@Override
	public List<String> existMerchant() {
		return repo.emails();
	}

//	Customer Password
	@Override
	public List<String> existCustomer() {
		return customerRepo.emails();
	}

//	
//	public Merchant decrypt(Merchant logo) {
//		String password = logo.getMerchantPassword();
//		Decoder en = Base64.getDecoder();
//		logo.setMerchantPassword(new String(en.decode(password)));
//		return logo;
//	}
//
//	@Override
//	public List<Merchant> getUser() {
//		List<Merchant> lost = repo.findAll();
//		List<Merchant> lnew = new ArrayList<>();
//		for (Merchant login : lost) {
//			Merchant ladd = decrypt(login);
//			lnew.add(ladd);
//		}
//		System.out.println(lnew);
//		return lnew;
//	}

// Auto Generated Email
	void sendEmail(String s, String p) {
		SimpleMailMessage msg = new SimpleMailMessage();
		msg.setTo(s);
		msg.setSubject("Testing from Spring Boot");
		msg.setText(p);
		javaMailSender.send(msg);
		System.out.println("hello");
	}

//	Merchant Passwords
	@Override
	public List<String> getPasswords() {
		List<String> passwords = repo.findByPassword();
		List<String> decodedPasswords = new ArrayList<>();
		for (String element : passwords) {
			Decoder en = Base64.getDecoder();
			String decoded = new String(en.decode(element));
			decodedPasswords.add(decoded);
		}
		return decodedPasswords;
	}

//	Customer Passwords
	@Override
	public List<String> customerPassword() {
		// TODO Auto-generated method stub
		List<String> passwords = customerRepo.customerByPassword();
		List<String> decodedPasswords = new ArrayList<>();
		for (String element : passwords) {
			Decoder en = Base64.getDecoder();
			String decoded = new String(en.decode(element));
			decodedPasswords.add(decoded);
		}
		return decodedPasswords;
	}

	// Customer CRUD operations
	@Override
	public List<Customer> searchAllCustomers() {
		if (customerRepo.findAll() != null)
			return customerRepo.findAll();
		else
			return null;
	}

	@Override
	public Customer updateCustomer(Customer cdb, int id) {
		if (customerRepo.findById(id) != null) {
			customerRepo.save(cdb);
			return customerRepo.findById(id).get();
		} else
			return null;
	}

	@Override
	public Customer findById(int id) {
		return customerRepo.findById(id).get();
	}

	@Override
	public Customer getCustomerById(int id) {
		Optional<Customer> ce = customerRepo.findById(id);
		if (!ce.isPresent())
			return null;
		else
			return customerRepo.findById(id).get();
	}

	@Override
	public void deleteCustomer(int id) {
		customerRepo.deleteById(id);
	}

	//Merchant CRUD operations
	@Override
	public Merchant getMerchantById(int id) {
		return repo.findById(id).get();
	}
	@Override
	public Merchant getByUsername(String username) {
		// TODO Auto-generated method stub
		return repo.findByName(username);
	}

	@Override
	public void deleteMerchant(int id) {
		repo.deleteById(id);
	}

	@Override
	public List<Merchant> getAllMerchants() {
		return repo.findAll();
	}

	@Override
	public Merchant updateMerchant(int id, Merchant ce) {
		return repo.save(ce);
	}
	
	
	/*
	 * 
	 * Merchant services.....
	 * 
	 */
	
	
	@Override
	public boolean saveProduct(Product prod) {

		if (pRepo.save(prod) != null)
			return true;
		else
			return false;

	}

	@Override
	public List<Product> displayAllByPriceAsc() {
		Sort price = new Sort(Sort.Direction.ASC, "price");
		return pRepo.findAllProductsByPriceAsc(price);
	}

	@Override
	public List<Product> displayAllByPriceDsc() {
		Sort price = new Sort(Sort.Direction.DESC, "price");
		return pRepo.findAllProductsPriceDsc(price);
	}

	@Override
	public List<Product> displayAllByNewest() {
		return pRepo.findAllProductsNewest();
	}

	@Override
	public List<Product> displayByPrice() {

		return pRepo.findAllProductsByPrice();
	}

	@Override
	public Product updateProduct(Product prod) {
		if(pRepo.findById(prod.getProductId())!=null)
		{
			
			pRepo.save(prod);
			return prod;
		}
		else
		{
			return null;
		}
	}

//	@Override
//	public List<Product> getAll() {
//		return pRepo.findAll();
//	}
	
	@Override
	public Product getProdById(int id)
	{
		return pRepo.findById(id).get();
	}
	
	@Override
	public List<Product> searchByName(String name,int mid) {
		return pRepo.searchByName(name, mid);
	}
	
	@Override
	public List<Product> searchByBrand(String brand,int mid) {
		return pRepo.searchByBrand(brand, mid);
	}
	
	@Override
	public List<Product> searchByCategory(String cat,int mid) {
		return pRepo.searchByCategory(cat, mid);
	}

	@Override
	public boolean deleteByProductId(int id) {
		pRepo.deleteById(id);
		return true;
	}

	@Override
	public List<Product> getAllProductsByMerchId(int id) {
		return pRepo.getProductByMerchid(id);
	}

	@Override
	public Feedback saveFeedback(Feedback f) {
		fRepo.save(f);
		Product prod=new Product();
		prod=pRepo.findById(f.getProdId()).get();
		int prevSum=prod.getPrevVoteSum()+f.getStars();
		int voteCnt=prod.getVoteCount()+1;
		double avgVotes=prevSum/voteCnt;
		
		prod.setPrevVoteSum(prevSum);
		prod.setVoteCount(voteCnt);
		prod.setAvgRating(avgVotes);
		pRepo.save(prod);
		return f;
	}

	@Override
	public List<Feedback> getTopFeedback(int pid) {
		
		return fRepo.getFeedbackByProductId(pid);
	}
	
	
	/*
	 * 
	 * Customer Services 
	 * 
	 */
	
	

	public double coupon(int order_id, int couId) {
		Coupon coupon = couponRepo.getCouponByCustomId(couId);
		CustomerOrderBean customer = oRepo.getOrderById(order_id);
		double price = customer.getPrice() - ((customer.getPrice() * coupon.getDiscount()) / 100);
		customer.setPrice(price);
		couponRepo.deleteById(couId);

		return price;
	}

	
	

	@Override
	public boolean updateProductAtEnd(List<Product> pro, int pro_id) {
		
	for (Product product : pro) {
		product.setSoldStock(1);
	}
	return true;
	}

	@Override
	public void saveDelivery(DeliveryDetailsBean delBean) {
		delRepo.save(delBean);

	}

	public List<Cartlist> generateInvoice(int custId) {
		return invoiceRepo.getInvoiceById(custId);

	}


	public List<DeliveryDetailsBean> getAll() {
		return delRepo.findAll();
	}

	public List<DeliveryDetailsBean> getById(int d_id) {
		return delRepo.find(d_id);
	}

	public List<DeliveryDetailsBean> returnGood(int d_Id) {
		DeliveryDetailsBean db = delRepo.findById(d_Id).get();
//		DeliveryDetailsBean db=delRepo.returnGood(productId);
		db.setStatus("Returned");
		int i = db.getProId();
		Product pd = pRepo.findById(i).get();
		pd.setStock(pd.getStock() + db.getQuantity());
		pRepo.save(pd);
		delRepo.save(db);
		return delRepo.findAll();

	}

	public void setDetails(ShippingDetailsBean shipDetails,int cust_id) {

		/*
		 * cartList=cartRepo.findby(cartList.class).get();
		 * shipDetails.setCustomer_Id(cartList.getCustomer_Id());
		 */
		shipDetails.setCustomerId(cust_id);
		shipRepo.save(shipDetails);
	}

	@Override
	public List<ShippingDetailsBean> showdetails(int cust_id) {
		// TODO Auto-generated method stub
		return shipRepo.find(cust_id);
	}

	
	/*
	 * Customer Service part 2
	 * 
	 */
	
	@Override
	public Product searchById(int id) {
		return customerSearchRepo.findById(id).get();
	}

	@Override
	public List<Product> getProductByName(String name) {
		return customerSearchRepo.getProductByName(name);
	}

	@Override
	public List<Product> getProductByBrand(String brand) {
		return customerSearchRepo.getProductByBrand(brand);
	}

	@Override
	public List<Product> getProductByCategory(String category) {
		return customerSearchRepo.getProductByCategory(category);
	}
	
	public void addtoWishList(WishList wishlist) {
		wishRepo.save(wishlist);
		
	}
	public List<WishList> getWishProducts(int cust_id) {
		// TODO Auto-generated method stub
		return wishRepo.getWishListById(cust_id);
	}
	public List<WishList> deletewish(int wishId) {
		wishRepo.deleteById(wishId);
		return wishRepo.findAll();
		
	}
	
	
	@Override
	public boolean addToCart(Cartlist cl) {

		double ans = this.calculation(cl.getProId().getProductId(), cl);
		cl.setTprice(ans);
		// System.out.println(ans);
//		double finalprice = cl.getFinalprice() + ans;
//		cl.setFinalprice(finalprice);
		cartRepo.save(cl);
		return true;
	}
	@Override
	public List<Cartlist> getAll(int cust_id) {
		// TODO Auto-generated method stub
		return cartRepo.getCartListById1(cust_id);
	}

	@Override
	public boolean deletecart(int cart_id) {
		// TODO Auto-generated method stub
		 cartRepo.deleteById(cart_id);
		 return true;
	} 

	@Override
	public Cartlist getcart(Product p,int cust_id,int quantity) {
		// TODO Auto-generated method stub
		Cartlist cart=new Cartlist(cust_id,p,cust_id,quantity);
		return cart;
	}

	@Override
	public WishList getwish(Product p, int cust_id) {
		// TODO Auto-generated method stub
		WishList wish=new WishList(p,cust_id);
		return wish;
	}
	
	public double calculation(int id, Cartlist cart) {
		Product pro = pRepo.findById(id).get();
		double price1 = pro.getPrice() * cart.getQuantity();
//		System.out.println(price1);
		double totalPrice = price1 - ((price1 * pro.getDiscount() * 1.0) / 100);
		cart.setTprice(totalPrice);
//		System.out.println(totalPrice);
		return totalPrice;
	}
	@Override
	public double buynow(int pro_id, int qty) {
		Product pro = pRepo.findById(pro_id).get();
		double price = pro.getPrice() * qty;

		double totalPrice = price - ((price * pro.getDiscount() * 1.0) / 100);
		System.out.println(totalPrice);
		
		CustomerOrderBean order = new CustomerOrderBean();
		order.setPrice(totalPrice);
		
		return totalPrice;
		
	
	}
	@Override
	public List<Cartlist> getFinal(int custID) {
		double price=0;
		CustomerOrderBean order = new CustomerOrderBean();
				
		List<Cartlist> cartlist = cartRepo.getCartListById1(custID);
		for(int i=0;i<cartlist.size();i++) {
			price = price+cartlist.get(i).getTprice();
			cartlist.get(i).setFinalprice(price);
//			System.out.println(price);
			order.setPrice(price);
		}
		return cartlist;
		
	}

	@Override
	public Customer getCustomer(int cust_id) {
		// TODO Auto-generated method stub
		return customerRepo.findById(cust_id).get();
	}

	@Override
	public Customer updateCustomer(Customer c) {
		// TODO Auto-generated method stub
		return customerRepo.save(c);
	}

	@Override
	public List<Cartlist> getAllCart(int cust_id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Customer throwCustomer(String email) {
		return customerRepo.findByName(email);
	}
	
	
	public void createCustomerOrder(CustomerOrderBean custorder) {
		oRepo.save(custorder);
	}

	@Override
	public void createDelivery(DeliveryDetailsBean deli) {
		deli.setStatus("delivered");
		LocalDate date=LocalDate.now();
		deli.setOrderDate(date);
		List<ShippingDetailsBean> add=shipRepo.find(deli.getCustomerId());
		deli.setDeliveredAddress(add.get(0).getCity());
		delRepo.save(deli);
		
	}
	
	

	
	
	
	
}