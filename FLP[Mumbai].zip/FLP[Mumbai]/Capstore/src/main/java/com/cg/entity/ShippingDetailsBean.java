package com.cg.entity;

import javax.persistence.*;

@Entity
@Table(name="shipping_details")
public class ShippingDetailsBean {
	
	@Id
	@GeneratedValue(generator="ship_seq")
	private int shippingId;
	
	@Column(length=30)
	private String customerName;
	
	@Column(length=20)
	private String flatNo;
	
	@Column(length=20)
	private String roadName;
	
	@Column(length=20)
	private String areaName;
	
	@Column(length=20)
	private String city;
	
	@Column(length=20)
	private String state;
	
	@Column(length=6)
	private int pincode;
	
	@Column(length=30)
	private String emailId;
	
	@Column(length=10)
	private long phoneNo;	
	
	private int customerId;
	
	public ShippingDetailsBean() {
		// TODO Auto-generated constructor stub
	}

	

	public ShippingDetailsBean(int shippingId, String customerName, String flatNo, String roadName, String areaName,
			String city, String state, int pincode, String emailId, long phoneNo, int customerId) {
		super();
		this.shippingId = shippingId;
		this.customerName = customerName;
		this.flatNo = flatNo;
		this.roadName = roadName;
		this.areaName = areaName;
		this.city = city;
		this.state = state;
		this.pincode = pincode;
		this.emailId = emailId;
		this.phoneNo = phoneNo;
		this.customerId = customerId;
	}



	public int getShippingId() {
		return shippingId;
	}



	public void setShippingId(int shippingId) {
		this.shippingId = shippingId;
	}



	public String getCustomerName() {
		return customerName;
	}



	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}



	public String getFlatNo() {
		return flatNo;
	}



	public void setFlatNo(String flatNo) {
		this.flatNo = flatNo;
	}



	public String getRoadName() {
		return roadName;
	}



	public void setRoadName(String roadName) {
		this.roadName = roadName;
	}



	public String getAreaName() {
		return areaName;
	}



	public void setAreaName(String areaName) {
		this.areaName = areaName;
	}



	public String getCity() {
		return city;
	}



	public void setCity(String city) {
		this.city = city;
	}



	public String getState() {
		return state;
	}



	public void setState(String state) {
		this.state = state;
	}



	public int getPincode() {
		return pincode;
	}



	public void setPincode(int pincode) {
		this.pincode = pincode;
	}



	public String getEmailId() {
		return emailId;
	}



	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}



	public long getPhoneNo() {
		return phoneNo;
	}



	public void setPhoneNo(long phoneNo) {
		this.phoneNo = phoneNo;
	}



	public int getCustomerId() {
		return customerId;
	}



	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}



	@Override
	public String toString() {
		return "ShippingDetailsBean [shippingId=" + shippingId + ", customerName=" + customerName + ", flatNo=" + flatNo
				+ ", roadName=" + roadName + ", areaName=" + areaName + ", city=" + city + ", state=" + state
				+ ", pincode=" + pincode + ", emailId=" + emailId + ", phoneNo=" + phoneNo + ", customerId="
				+ customerId + "]";
	}
}
