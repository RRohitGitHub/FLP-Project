package com.cg.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;


import com.cg.entity.Customer;
import com.cg.entity.Merchant;

@Repository
public interface CapstoreRepo extends JpaRepository<Customer, Integer> {
	@Query("SELECT customerEmail FROM Customer")
	List<String>emails();

	@Query("SELECT customerPassword FROM Customer")
	public List<String> customerByPassword();
	
	@Query("from Customer where customerEmail=:email")
	public Customer findByName(@Param("email") String email);
	
	
}
