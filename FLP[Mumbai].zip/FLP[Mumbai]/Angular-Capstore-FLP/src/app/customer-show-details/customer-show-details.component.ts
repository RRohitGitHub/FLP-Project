import { Component, OnInit } from '@angular/core';
import { ShippingModel } from '../shipping.model';
import { ShipDetailsService } from '../service/ship-details.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-customer-show-details',
  templateUrl: './customer-show-details.component.html',
  styleUrls: ['./customer-show-details.component.css']
})
export class CustomerShowDetailsComponent implements OnInit {

  shipdetails:any[]=[];
  ship:any;
  hide:boolean;
  constructor(private service:ShipDetailsService,private router:Router) {
    this.ship=new ShippingModel();
   }

  ngOnInit() {
  }

  showdetails(){
   this.service.showdetails().subscribe(data => {this.shipdetails=data}, error => console.log(error));
   this.hide=true;
  }
  proceed(){
    this.router.navigate(['customer-payment']);
  }
  newAddress(){
    this.router.navigate(['customer-shipdetails']);
  }


}
