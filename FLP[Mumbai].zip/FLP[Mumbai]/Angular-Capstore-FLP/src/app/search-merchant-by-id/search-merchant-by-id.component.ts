import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../service/customer.service';
import { MerchantModel } from '../merchant.model';
import { Router } from '@angular/router';

@Component({
  selector: 'app-search-merchant-by-id',
  templateUrl: './search-merchant-by-id.component.html',
  styleUrls: ['./search-merchant-by-id.component.css']
})
export class SearchMerchantByIdComponent implements OnInit {
  mer:any;
  submitted:boolean;
    constructor(private service: CustomerService, private router : Router) {
      this.mer=new MerchantModel();
     }
  
    ngOnInit() {
    }
    search(){
    this.submitted=true;
     this.service.searchMerchantById(this.mer.merchantId).subscribe(data => {this.mer = data, console.log(this.mer)});
    }
    update(i:number){
      this.service.merchant=this.mer.merchantId;
      this.router.navigate(['admin-front/update-merchant']);
     }

    
}
