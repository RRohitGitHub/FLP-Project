import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ShipDetailsService } from 'src/app copy/service/ship-details.service';

@Component({
  selector: 'app-customer-payment',
  templateUrl: './customer-payment.component.html',
  styleUrls: ['./customer-payment.component.css']
})
export class CustomerPaymentComponent implements OnInit {

  constructor(private router:Router,private service:ShipDetailsService) { }

  ngOnInit() {
  }
cod(){
  alert("successfully placed");
this.router.navigate(['customer-generate-invoice']);
}
credit(){
  this.router.navigate(['customer-credit']);
}
debit(){
  this.router.navigate(['customer-debit']);
}

}
