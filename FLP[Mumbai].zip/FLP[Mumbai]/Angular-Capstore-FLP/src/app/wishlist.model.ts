import { Product } from "./product.model";

    export class wishlist{
        public wishId:number;
        public customerId:number;
        public product:Product;


}