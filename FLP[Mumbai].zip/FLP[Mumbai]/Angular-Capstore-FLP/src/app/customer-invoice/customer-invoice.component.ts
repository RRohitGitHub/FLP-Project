import { Component, OnInit } from '@angular/core';
import { CustomerOrderModel } from '../customerorder.model';
import { ShipDetailsService } from '../service/ship-details.service';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { FeedbackModel } from '../feedback.model';
import { Cartlist } from '../cart.model';
import { ProductHomePageService } from '../service/product-home-page.service';

@Component({
  selector: 'app-customer-invoice',
  templateUrl: './customer-invoice.component.html',
  styleUrls: ['./customer-invoice.component.css']
})
export class CustomerInvoiceComponent implements OnInit {

  invoices:any[]=[];
  in:CustomerOrderModel;
  order:any;
  invoice:Cartlist;

// Feedback
ratingFeedback:FeedbackModel;
  rating:number[]=[];
  feedbacks:any[]=[];
  prodId:number;
  flag:boolean=false;
  
  constructor(private service:ShipDetailsService,private http:HttpClient,private route:Router,private merchantservice:ProductHomePageService) { 
  // this.invoices=new CustomerOrderModel();
    this.in=new CustomerOrderModel();
    this.invoice=new Cartlist();

    //Feedback

    this.ratingFeedback = new FeedbackModel();
    this.feedbacks[0]=new FeedbackModel();
    this.ratingFeedback.prodId = 4104;
    this.rating = [1,2,3,4,5];
  }

  ngOnInit() {
   this.service.getInvoice().subscribe(data=> {this.invoices=data},error=>console.log(error));
   
  }

  
   /* feedback(index:number){
         this.merchantservice.feedback(index).subscribe(data=>{this.in=data},error=>console.log(error));
       }*/

       submitFeedback(){
        this.merchantservice.storeFeedback(this.ratingFeedback).subscribe(data=>{console.log(data)},error=>{console.log(error)});
        // this.route.navigate(['customer-ordered-items']);
      }
    

}
