import { Component, OnInit } from '@angular/core';
import { ShippingModel } from '../shipping.model';
import { ShipDetailsService } from '../service/ship-details.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-customer-shipping-details',
  templateUrl: './customer-shipping-details.component.html',
  styleUrls: ['./customer-shipping-details.component.css']
})
export class CustomerShippingDetailsComponent implements OnInit {

  ship:ShippingModel;
  constructor(private service: ShipDetailsService,private routes : Router) {
    this.ship=new ShippingModel();
   }

  ngOnInit() {
  }

  

  showdetails(){
    this.service.shipdetails(this.ship).subscribe(data => {this.ship=data,console.log(this.ship)}, error => console.log(error));
    this.ship = new ShippingModel();
    var ans=confirm("The Product will be delivered to mentioned Address!!");
    if(ans)
     this.routes.navigate(['customer-payment']);
     else
      this.routes.navigate(['customer-showdetails']);
  }

}
