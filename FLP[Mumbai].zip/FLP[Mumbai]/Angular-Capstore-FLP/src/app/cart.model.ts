import { Product } from "./product.model";

export class Cartlist{
    public cartId : number;
	public proId : Product;
    public custId : number;
    public quantity : number;
    public tprice:number;
    public finalprice : number;
}