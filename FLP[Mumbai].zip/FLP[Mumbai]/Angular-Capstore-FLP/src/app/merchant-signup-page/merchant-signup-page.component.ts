import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { MerchantModel } from '../merchant.model';
import { Router } from '@angular/router';

@Component({
  selector: 'merchant-signup',
  templateUrl: './merchant-signup-page.component.html',
  styleUrls: ['./merchant-signup-page.component.css']
})
export class MerchantSignupPageComponent {
  merchant:any;
  existEmail:any[]=[];
  index:number;
  checkStatus:boolean;
  types:string[];
  flag:boolean;
 
  constructor(private http:HttpClient,private router : Router){
    this.merchant=new MerchantModel();
    this.types=['Merchant','Third Party Merchant'];
   
this.http.get<any[]>('http://localhost:9990/capstore/exist')
.subscribe(data => {this.existEmail=data,console.log(this.existEmail)}, error => console.log(error));
  }
  add(){
   this.flag=true;
    this.check();
    this.http.post('http://localhost:9990/capstore/'+'add',this.merchant)
    .subscribe(data => {this.merchant=data,console.log(this.merchant)}, error => console.log(error)); 
    
    

  }
  check(){
    for( let index=0;index<this.existEmail.length;index++){
        if(this.existEmail[index]==this.merchant.merchantEmail){
          this.flag=false;
          this.checkStatus=true;
      
        }
    }
  }
 
  login(){
    this.router.navigate(['login-page']);
  }
}
