import { Injectable } from '@angular/core';
import { ShippingModel } from '../shipping.model';
import { Product } from '../product.model';
import { Cartlist } from '../cart.model';
import { wishlist } from '../wishlist.model';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { CustomerOrderModel } from '../customerorder.model';
import { FeedbackModel } from 'src/app copy/feedback.model';
import { CustomerModel } from '../customer.model';
import { DeliveryModel } from '../delivery.model';

@Injectable({
  providedIn: 'root'
})
export class ShipDetailsService {

  baseUrl:string="http://localhost:9990/capstore";
  customer: CustomerModel;
  showdetail:ShippingModel[]=[];
  products:Product[]=[];
 product:Product;
 cart:Cartlist;
 wish:wishlist;
 custid:number;
 prodId:number;
 id:number;
 customerorder:CustomerOrderModel;
 delivery:DeliveryModel;
  constructor(private http : HttpClient) { }

  
  addToCustomer(customerOrder :CustomerOrderModel):Observable<any> //add component
  {
    return this.http.post(`${this.baseUrl}`+`createcustomerorder`,customerOrder);
  }

addtodelivery(deli:DeliveryModel):Observable<any>
{
  return this.http.post(`${this.baseUrl}/setdelivery`,deli);
}

  shipdetails(ship:ShippingModel):Observable<any>{
    return this.http.post(`${this.baseUrl}/shippingdetails/${this.customer.customerId}`, ship);
  }

  showdetails():Observable<any>{
     return this.http.get(`${this.baseUrl}/showdetails/${this.customer.customerId}`);
  }
  invoice:CustomerOrderModel[]=[];






  getInvoice():Observable<any>{
    return this.http.get(`${this.baseUrl}/invoiceGenerated/${this.customer.customerId}`);
  }
  

  feedback(id:number):Observable<any>{
    return this.http.put(`${this.baseUrl}/feedback/${id}`,id);
  }

  storeFeedback(feedback:FeedbackModel):Observable<any>{
    return this.http.post(`${this.baseUrl}/capstore/storeFeedback`,feedback);
  }

  
  getDelivery(index:number):Observable<any>{
    return this.http.get(`${this.baseUrl}/get/${index}`)
  }

 
  returnGood(id:number):Observable<any>{
    return this.http.put(`${this.baseUrl}/return/${id}`,id);
  }

  finalPrie(cid : number):Observable<any>{
    return this.http.get(`${this.baseUrl}/final/${cid}`);
  }

  buyNow(id : number, qty : number):Observable<any>{
    console.log(qty);
    return this.http.get(`${this.baseUrl}/buy/${id}/${qty}`);
  }


  
  getCart1(id : number) : Observable<any> {
    return this.http.get<Cartlist[]>(`${this.baseUrl}/capstore/get/${this.prodId}`);
  }

  getProductById(id:number):Observable<any>{
    return this.http.get(`${this.baseUrl}/pro/${this.prodId}`);
  }
  getAll():Observable<any> {
    return this.http.get<Cartlist[]>(`${this.baseUrl}/get`);
  }

  remove(cart:Cartlist) : Observable<any>{
    return this.http.delete(`${this.baseUrl}/remove/${cart.cartId}`);
  }





  //alekya
  searchByName(product:Product){
    return this.http.get<Product[]>(this.baseUrl + '/product/name/'+product.searchitem);
  }
  searchByCategory(product:Product){
    return this.http.get<Product[]>(this.baseUrl + '/product/category/'+product.searchitem);
  }
  searchByBrand(product:Product){
    return this.http.get<Product[]>(this.baseUrl + '/product/brand/'+product.searchitem);
  }
  saveproducts(prod:Product){
    this.products.push(prod);
  }
  getProduct(){
    return this.http.get<Product>(this.baseUrl + '/product/' + this.prodId);
  }
  getProducts(){
    return this.products;
  }

  addtoCart(product:Product,quantity:number)
  {
    return this.http.post(this.baseUrl+'/cart/add/'+this.customer.customerId+'/'+quantity,product);
  }





  getCart() {
    return this.http.get<Cartlist[]>(this.baseUrl + '/cart/'+this.customer.customerId);
  }

  deletecart(cart:Cartlist){
    return this.http.delete(this.baseUrl + '/CartItemDelete/'+cart.cartId);
  }

  addtowish(product:Product){
    return this.http.post(this.baseUrl+'/addtowishlist/'+this.customer.customerId,product);
  }

  getWish(id:number) {
    return this.http.get<wishlist[]>(this.baseUrl + '/getwishlist/'+this.customer.customerId);
  }

  deletewish(wish:wishlist){
    return this.http.delete(this.baseUrl + '/deletewish/'+wish.wishId);
  }
  getCustomerData(id:number){
    return this.http.get<CustomerModel>(this.baseUrl+'/getCustomer/'+this.customer.customerId);

  }

  updateCustomer(id:number,customer:CustomerModel) 
  {
 
    return this.http.put<CustomerModel>(this.baseUrl + '/updateProfile/'+this.customer.customerId,customer);
  }
  

  updateProduct(){
    return this.http.put<CustomerModel>(`${this.baseUrl}/placeOrder/${this.products[0].productId}`,this.products);

  }


  
}
