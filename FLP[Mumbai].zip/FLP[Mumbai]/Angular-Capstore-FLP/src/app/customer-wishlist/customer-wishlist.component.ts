import { Component, OnInit } from '@angular/core';
import { wishlist } from '../wishlist.model';
import { ShipDetailsService } from '../service/ship-details.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-customer-wishlist',
  templateUrl: './customer-wishlist.component.html',
  styleUrls: ['./customer-wishlist.component.css']
})
export class CustomerWishlistComponent implements OnInit {

  wishes:wishlist[];
  wish:wishlist;
  id:number;
    constructor( private Service: ShipDetailsService,private router:Router) { }
  
    ngOnInit() {
      this.Service.getWish(this.id).subscribe( data => {
          this.wishes = data;
        });
    }
    remove(wish:wishlist){
      this.Service.deletewish(wish).subscribe( data => {
    });
}

}
