import { Component, OnInit } from '@angular/core';
import { Product } from '../product.model';
import { ShipDetailsService } from '../service/ship-details.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-customer-view-product',
  templateUrl: './customer-view-product.component.html',
  styleUrls: ['./customer-view-product.component.css']
})
export class CustomerViewProductComponent implements OnInit {

  quantity:number;
  product:any;
  constructor(private service:ShipDetailsService,private router:Router) {
    this.product= new Product();
   }

  ngOnInit() {
   
    this.service.getProduct().subscribe(data=>{this.product= data,console.log(this.product)});

  }

  addCart(){
   if(this.quantity<=this.product.stock){
    this.service.addtoCart(this.product,this.quantity).subscribe();
    var ans=alert("added to cart");
    this.router.navigate(['customer-getlist']);
   }
    else
      alert("The quantity you required is out of stock!!");

  
  
}

wishlist()
  {
    this.service.addtowish(this.product).subscribe(data=>{});
    var ans=alert("added to wishlist");
    this.router.navigate(['customer-wishlist'])
  }

  
  buynow(){
    this.product.total= this.service.buyNow(this.product.productId,this.quantity)
    .subscribe(data => {
    });
		
    this.router.navigate(['customer-showdetails']);
  }

}
