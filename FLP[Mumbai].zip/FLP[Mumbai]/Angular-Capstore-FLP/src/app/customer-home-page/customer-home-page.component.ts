import { Component, OnInit } from '@angular/core';
import { HomeModel } from '../home.model';
import { Router } from '@angular/router';
import { ShipDetailsService } from '../service/ship-details.service';
import { Product } from 'src/app copy/product.model';

@Component({
  selector: 'app-customer-home-page',
  templateUrl: './customer-home-page.component.html',
  styleUrls: ['./customer-home-page.component.css']
})
export class CustomerHomePageComponent implements OnInit {

  product:any;
  home:HomeModel;
  searchby :string[];
  products:any[]=[];
  hide:boolean=true;
  constructor(private router:Router,private service:ShipDetailsService) {
    this.searchby = [ 'category', 'brand' , 'name'];
    this.home=new HomeModel();
    this.product= new Product();
    this.products[0]= new Product();
    
   }

  ngOnInit() {

  }
  
  User(){
    this.router.navigate(['customer-user']);
   this.hide=false;
  }

  upload(){
    if(this.product.searchitemby=='category'){
      this.service.searchByCategory(this.product).subscribe(data=>{this.products=data,console.log(this.products)});
    }
    if(this.product.searchitemby=='brand'){
      this.service.searchByBrand(this.product).subscribe(data=>{this.products= data,console.log(this.products)});

    }
    if(this.product.searchitemby=='name'){
      this.service.searchByName(this.product).subscribe(data=>{this.products= data,console.log(this.products)});
    }
  }

  search(){
    if(this.product.searchitemby=='name'){
      this.service.searchByName(this.product).subscribe(data=>{this.products= data,console.log(this.products)});
    }
    if(this.product.searchitemby=='category'){
           this.service.searchByCategory(this.product).subscribe(data=>{this.products=data,console.log(this.products)});
      }
  
    if(this.product.searchitemby=='brand'){
      this.service.searchByBrand(this.product).subscribe(data=>{this.products=data,console.log(this.products)});

    }
    console.log(this.products[0]);
    for(let i=0;i<this.products.length;i++){
      this.service.saveproducts(this.products[i]);
    
    }
    this.products=[];
    this.router.navigate(['customer-search']);
  }
}
