export class Product {
    productId : number;
    productName : string;
    brand : string;
    price : number;
    discount : number;
    stock : number;
    category : string;
    subCategory : string;
    avgRating : number;
    voteCount : string;
    prevVoteSum : string;
    soldStock : number;
    merchantId : number;
    searchitemby:string;
    searchitem:string;
    total : number;
}