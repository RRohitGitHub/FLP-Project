import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../service/customer.service';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { CustomerModel } from '../customer.model';
import { ShipDetailsService } from '../service/ship-details.service';

@Component({
  selector: 'customer-login',
  templateUrl: './customer-login-page.component.html',
  styleUrls: ['./customer-login-page.component.css']
})
export class CustomerLoginPageComponent implements OnInit {

  emails:any[]=[];
  flag:boolean;
  passwords:any[]=[];
  login : any;
  invalidLogin : false;
  t:boolean;
  constructor(private service:CustomerService, private router: Router, private http : HttpClient, private ship: ShipDetailsService){
    this.login= new CustomerModel();
    this.http.get<any[]>('http://localhost:9990/capstore/customerEmail')
    .subscribe(data => {this.emails=data,console.log(this.emails)}, error => console.log(error));
    this.http.get<any[]>('http://localhost:9990/capstore/customerPassword')
    .subscribe(data => {this.passwords=data,console.log(this.passwords)}, error => console.log(error));
}

  ngOnInit() {
  }

  onSubmit() {
    for(let j=0;j<this.emails.length;j++){
      if(this.login.customerEmail==this.emails[j])
        this.t=true;

   }
   if(this.t==true){
   for(let i=0;i<this.emails.length;i++)
       {if(this.login.customerEmail==this.emails[i])
      {if(this.login.customerPassword==this.passwords[i]){
        this.http.get<any>(`http://localhost:9990/capstore/throwCustomer/${this.login.customerEmail}`)
    .subscribe(data => {console.log(this.ship.customer),this.ship.customer=data}, error => console.log(error));
          this.router.navigate(['customer-home']);
      }
        else
          alert("Invalid Credentials!!");
      }
    }
   }
   else
   alert("Email ID not present!");
  }  
  
  signUp(){
    console.log("signed up");
    this.router.navigate(['customer-signup']);
  }

}
