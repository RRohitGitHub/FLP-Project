import { Component, OnInit } from '@angular/core';
import { CustomerModel } from 'src/app copy/customer.model';
import { ShipDetailsService } from '../service/ship-details.service';

@Component({
  selector: 'app-customer-profile',
  templateUrl: './customer-profile.component.html',
  styleUrls: ['./customer-profile.component.css']
})
export class CustomerProfileComponent implements OnInit {

  edit:any;
  id:number;
    constructor(private service:ShipDetailsService) { 
      this.edit=new CustomerModel();
      id:this.edit.customerId;
      id:Number;
    }
  
    ngOnInit() {
     this.service.getCustomerData(this.id).subscribe(data=>this.edit=data);
     this.edit=new CustomerModel();
    }
  
    update(edit:CustomerModel){
      var ans=confirm("Are you sure you want to edit ?")
      if(ans)
      {
       
  this.service.updateCustomer(edit.customerId,edit).subscribe(data=>{this.edit=data})
  this.edit=new CustomerModel();
    
    }
  }


}
