import { Component, OnInit } from '@angular/core';
import { Payment } from '../payment.model';
import { Router } from '@angular/router';

@Component({
  selector: 'app-customer-debit-card',
  templateUrl: './customer-debit-card.component.html',
  styleUrls: ['./customer-debit-card.component.css']
})
export class CustomerDebitCardComponent implements OnInit {

  debit : Payment;
  
  constructor(private router:Router) {
    this.debit = new Payment();
   }

  ngOnInit() {
  }
  addcard()
  {
    
    alert("Payment Successful!!!! \nOrder is Successfully Placed");
    this.router.navigate(['customer-generate-invoice']);
    
  }
}
