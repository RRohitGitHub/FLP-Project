import { Component, OnInit } from '@angular/core';
import { Payment } from '../payment.model';
import { Router } from '@angular/router';

@Component({
  selector: 'app-customer-credit-card',
  templateUrl: './customer-credit-card.component.html',
  styleUrls: ['./customer-credit-card.component.css']
})
export class CustomerCreditCardComponent implements OnInit {

  credit : Payment;
  constructor(private router:Router) {

    this.credit=new Payment();

   }

  ngOnInit() {
  }
  addcard(){
  this.router.navigate(['customer-generate-invoice']);

  }
}
