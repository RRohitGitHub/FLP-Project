import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-customer-user',
  templateUrl: './customer-user.component.html',
  styleUrls: ['./customer-user.component.css']
})
export class CustomerUserComponent implements OnInit {

  constructor(private router:Router) { }

  ngOnInit() {
  }

  wishlist(){
this.router.navigate(['customer-wishlist']);
  }
  cart(){
    console.log("in cart fun");
    this.router.navigate(['customer-getlist']);
  }
  profile(){
    this.router.navigate(['customer-proile']);
  }
  order(){
    this.router.navigate(['customer-ordered-items']);
  }

}
