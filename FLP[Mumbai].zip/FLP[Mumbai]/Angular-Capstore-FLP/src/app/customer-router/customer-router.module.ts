import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SearchAllCustomersComponent } from '../search-all-customers/search-all-customers.component';
import { MenuComponent } from '../menu/menu.component';
import { Routes, RouterModule } from '@angular/router';
import { UpdateCustomerComponent } from '../update-customer/update-customer.component';
import { SearchCustomerByIdComponent } from '../search-customer-by-id/search-customer-by-id.component';
import { LoginPageComponent } from '../login-page/login-page.component';
import { MerchantLoginPageComponent } from '../merchant-login-page/merchant-login-page.component';
import { MerchantSignupPageComponent } from '../merchant-signup-page/merchant-signup-page.component';
import { AdminFrontPageComponent } from '../admin-front-page/admin-front-page.component';
import { CustomerSignupComponent } from '../customer-signup/customer-signup.component';
import { CustomerLoginPageComponent } from '../customer-login-page/customer-login-page.component';
import { SearchAllMerchantsComponent } from '../search-all-merchants/search-all-merchants.component';
import { SearchMerchantByIdComponent } from '../search-merchant-by-id/search-merchant-by-id.component';
import { UpdateMerchantComponent } from '../update-merchant/update-merchant.component';
import { MerchantProfileComponent } from '../merchant-profile/merchant-profile.component';
import { AddProductsComponent } from '../add-products/add-products.component';
import { BusinessAnalysisComponent } from '../business-analysis/business-analysis.component';
import { DisplayProductComponent } from '../display-product/display-product.component';
import { EditProductMerchantComponent } from '../edit-product-merchant/edit-product-merchant.component';
import { SearchProductMerchantComponent } from '../search-product-merchant/search-product-merchant.component';
import { NavbarSearchComponent } from '../navbar-search/navbar-search.component';
import { FeedbackComponent } from '../feedback/feedback.component';
import { MerchantHomePageComponent } from '../merchant-home-page/merchant-home-page.component';
import { AdminLoginPageComponent } from '../admin-login-page/admin-login-page.component';
import { CustomerShowDetailsComponent } from '../customer-show-details/customer-show-details.component';
import { CustomerShippingDetailsComponent } from '../customer-shipping-details/customer-shipping-details.component';
import { CustomerInvoiceComponent } from '../customer-invoice/customer-invoice.component';
import { CustomerOrderedItemsComponent } from '../customer-ordered-items/customer-ordered-items.component';
import { CustomerShoppingCartComponent } from '../customer-shopping-cart/customer-shopping-cart.component';
import { CustomerCashOnDeliveryComponent } from '../customer-cash-on-delivery/customer-cash-on-delivery.component';
import { CustomerCreditCardComponent } from '../customer-credit-card/customer-credit-card.component';
import { CustomerDebitCardComponent } from '../customer-debit-card/customer-debit-card.component';
import { CustomerPaymentComponent } from '../customer-payment/customer-payment.component';
import { CustomerHomePageComponent } from '../customer-home-page/customer-home-page.component';
import { CustomerProfileComponent } from '../customer-profile/customer-profile.component';
import { CustomerWishlistComponent } from '../customer-wishlist/customer-wishlist.component';
import { CustomerUserComponent } from '../customer-user/customer-user.component';
import { SearchCustomerComponent } from '../search-customer/search-customer.component';
import { CustomerViewProductComponent } from '../customer-view-product/customer-view-product.component';
const routes : Routes = [

  {path:'menu',component:MenuComponent},
  {path:'admin-login', component:AdminLoginPageComponent},
  {path:'login-page', component:LoginPageComponent},
  {path:'merchant-login', component:MerchantLoginPageComponent},
  {path:'merchant-signup', component:MerchantSignupPageComponent},
  {path:'customer-signup', component:CustomerSignupComponent},
  {path:'customer-login', component:CustomerLoginPageComponent},
  
  //admin routers...
  {path:'admin-front', component:AdminFrontPageComponent,
  children:[
  {path:'search-merchant-id', component:SearchMerchantByIdComponent},
  {path:'update-merchant', component:UpdateMerchantComponent},
  {path:'list-customers',component:SearchAllCustomersComponent},
  {path:'update-customer', component:UpdateCustomerComponent},
  {path:'search-customer-id', component:SearchCustomerByIdComponent},
  {path:'list-merchants', component:SearchAllMerchantsComponent}
]
},
  //merchants routers...
  {path:'merchant-home',component:MerchantHomePageComponent,
  children:[
  {path : 'merchant-profile', component:MerchantProfileComponent},
  {path : 'merchant-add', component:AddProductsComponent},
  {path : 'merchant-analysis', component:BusinessAnalysisComponent},
  {path : 'merchant-display', component:DisplayProductComponent},
  {path : 'merchant-edit', component:EditProductMerchantComponent},
  {path : 'merchant-search', component:SearchProductMerchantComponent},
  {path:'merchant-navs',component:NavbarSearchComponent},
  {path:'merchant-feedback',component:FeedbackComponent}]
  },

  //customer routers
  {path:'customer-shipdetails',component:CustomerShippingDetailsComponent},
  {path:'customer-showdetails',component:CustomerShowDetailsComponent},
  {path:'customer-generate-invoice',component:CustomerInvoiceComponent},
  {path:'customer-ordered-items',component:CustomerOrderedItemsComponent},
  {path:'customer-getlist', component:CustomerShoppingCartComponent},
  {path:'customer-cod', component:CustomerCashOnDeliveryComponent},
  {path:'customer-credit', component:CustomerCreditCardComponent},
  {path:'customer-debit', component:CustomerDebitCardComponent},
  {path:'customer-payment', component:CustomerPaymentComponent},
  {path:'customer-home',component:CustomerHomePageComponent},
  {path:'customer-proile',component:CustomerProfileComponent},
  {path:'customer-wishlist',component:CustomerWishlistComponent},
  {path:'customer-user',component:CustomerUserComponent},
  {path:'customer-search',component:SearchCustomerComponent},
  {path:'customer-view',component:CustomerViewProductComponent}

];
@NgModule({
  imports: [
    CommonModule, RouterModule.forRoot(routes)
  ],
  declarations: [],
  exports:[RouterModule]
})
export class CustomerRouterModule { }
