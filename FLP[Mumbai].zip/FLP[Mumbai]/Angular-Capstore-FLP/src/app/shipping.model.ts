export class ShippingModel{
    private customerId:number;
    private customerName:string;
    private flatNo:string;
    private roadName:string;
    private areaName:string;
    private city:string;
    private state:string;
    private pincode:number;
    private emailId:string;
    private phoneNo:number;

}