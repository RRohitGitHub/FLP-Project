import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customer-debit-card',
  templateUrl: './customer-debit-card.component.html',
  styleUrls: ['./customer-debit-card.component.css']
})
export class CustomerDebitCardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
