import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerDebitCardComponent } from './customer-debit-card.component';

describe('CustomerDebitCardComponent', () => {
  let component: CustomerDebitCardComponent;
  let fixture: ComponentFixture<CustomerDebitCardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CustomerDebitCardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerDebitCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
