import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchAllMerchantsComponent } from './search-all-merchants.component';

describe('SearchAllMerchantsComponent', () => {
  let component: SearchAllMerchantsComponent;
  let fixture: ComponentFixture<SearchAllMerchantsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchAllMerchantsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchAllMerchantsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
