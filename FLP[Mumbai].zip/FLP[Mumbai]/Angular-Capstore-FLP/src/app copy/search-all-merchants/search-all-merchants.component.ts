import { Component, OnInit } from '@angular/core';
import { MerchantModel } from '../merchant.model';
import { CustomerService } from '../service/customer.service';
import { Router } from '@angular/router';
import { MerchantLoginPageComponent } from '../merchant-login-page/merchant-login-page.component';

@Component({
  selector: 'app-search-all-merchants',
  templateUrl: './search-all-merchants.component.html',
  styleUrls: ['./search-all-merchants.component.css']
})
export class SearchAllMerchantsComponent implements OnInit {

  merchantlist: any[];
  crud:MerchantModel;
  constructor(private service:CustomerService,private router: Router) {
    this.service.searchAllMerchants().subscribe(data => {this.merchantlist = data, console.log(this.merchantlist)});;
   }

  ngOnInit() {
  }
  delete(i:number){
    this.service.deleteMerchant(this.merchantlist[i].merchantId)
    .subscribe(data => {this.merchantlist[i]= data, console.log(this.crud)});
    this.merchantlist[i] = new MerchantModel();
    this.router.navigate(['admin-front/list-merchants']);
  }

  update(i:number){
   this.service.merchant=this.merchantlist[i].merchantId;
   this.router.navigate(['admin-front/update-merchant']);
  }


}
