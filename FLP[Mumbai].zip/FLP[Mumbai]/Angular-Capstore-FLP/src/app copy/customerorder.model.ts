export class CustomerOrderModel{
    public orderId:number;
    public proId:number;
    public proName:string;
    public price:number;
    public orderDate:Date;
    public paymentMode:string;
    public deliveredAddress:string;
    public quantity:number;
    public merchantId:number;
}