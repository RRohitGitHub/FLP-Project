export class DeliveryModel{
    public dId:number;
    public customerId:number;
    public proId:number;
	public proName:string;
    public price:number;
    public status:string;
    public orderDate:Date;
    public merchantId:number;
    public quantity:number;
    public deliveredAddress:string;
}