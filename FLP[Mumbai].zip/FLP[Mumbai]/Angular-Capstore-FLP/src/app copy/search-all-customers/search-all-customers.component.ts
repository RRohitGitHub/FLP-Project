import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../service/customer.service';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { CustomerModel } from '../customer.model';
import { Window } from 'selenium-webdriver';

@Component({
  selector: 'list-customers',
  templateUrl: './search-all-customers.component.html',
  styleUrls: ['./search-all-customers.component.css']
})
export class SearchAllCustomersComponent implements OnInit {
  customers : any[]=[];
  customer : any;
  hide : boolean;
  flag:boolean;

  constructor(private service : CustomerService, private router : Router, private http : HttpClient) {  
    this.customer = new CustomerModel();
    this.http.get<any[]>('http://localhost:9990/capstore/findAllCustomers') 
    .subscribe(data => {this.customers=data,  console.log(this.customers)}, error => console.log(error));
    this.hide = true;
     }

  ngOnInit() {
    
  }

  updateDetails(index : number){
    
    var con = confirm("Are you sure you want to edit?");
    if(con){
      this.flag=true;
      this.service.edit=this.customers[index].customerId;
      this.router.navigate(['admin-front/update-customer']);    
    }
    else if(this.service.searchById==null)
      alert("No record found for the id " + index);
    
     
  }

  deleteDetails(index : number){
    var con = confirm("Are you sure you want to delete?");
    console.log(this.customers[index].customerId);
    if(con){
      console.log(this.customers[index].customerId);
      this.service.delete(this.customers[index].customerId)
      .subscribe(data=> {this.customer=data},error => console.log(error));
      this.customer=new CustomerModel();
      this.router.navigate(['admin-front/list-customers']);
      window.location.reload();
    } 
  }

}
