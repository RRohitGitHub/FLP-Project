import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchAllCustomersComponent } from './search-all-customers.component';

describe('SearchAllCustomersComponent', () => {
  let component: SearchAllCustomersComponent;
  let fixture: ComponentFixture<SearchAllCustomersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchAllCustomersComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchAllCustomersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
