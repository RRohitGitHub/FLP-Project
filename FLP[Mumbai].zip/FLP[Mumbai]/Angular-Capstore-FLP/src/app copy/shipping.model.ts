export class ShippingModel{
    private customer_id:number;
    private customer_name:string;
    private flat_no:string;
    private road_name:string;
    private area_name:string;
    private city:string;
    private state:string;
    private pincode:number;
    private email_id:string;
    private phone_no:number;

}