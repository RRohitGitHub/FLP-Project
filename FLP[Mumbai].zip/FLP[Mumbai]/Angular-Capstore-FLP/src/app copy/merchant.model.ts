export class MerchantModel{
    merchantId:number;  
    merchantType:string;
    merchantName:string;
    merchantPhone:string;
    merchantEmail:string;
    merchantAadhar:string;
    merchantAddress:string;
    merchantPassword:string;
}