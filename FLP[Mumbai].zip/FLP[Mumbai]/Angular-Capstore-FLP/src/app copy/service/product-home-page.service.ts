import { Injectable } from '@angular/core';
import { Product } from '../product.model';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { FeedbackModel } from '../feedback.model';
import { MerchantModel } from '../merchant.model';

@Injectable({
  providedIn: 'root'
})
export class ProductHomePageService {

  products : Product[]=[];
  searchProducts : any[]=[];
  index : number;
  editIndex:number;
  navBarSearch:string;
  merchantId:number;
  currentMerchant:MerchantModel;
  
  basicUrl: string = "http://localhost:9990/capstore/merchant/";

  constructor(private http:HttpClient, private router : Router) {
    
   }

  getMerchant()
  {

  }

  // storedetails(prod:Product){
  //   this.products.push(prod);
  // }

  updateProduct(product: Product):Observable<any> // save updated Product data to database 
  {
    return this.http.put(`${this.basicUrl}`+`update`,product);
  }

  addProduct(product : Product):Observable<any> //add component
  {
    return this.http.post(`${this.basicUrl}`+`create`,product);
  }

  showProducts():Observable<any>{ // display component
    console.log(this.currentMerchant);
    return this.http.get(`${this.basicUrl}/getAllProducts`);
  }

  deleteProduct(id:number,i:number):Observable<any> //delete functionality of Display
  {
   this.products.splice(i,1);

    return this.http.get(`${this.basicUrl}/delete/${id}`);
  }

  getProductById(i:number):Observable<any> // Fetch product object on click of EDIT button
  {
    return this.http.get(`${this.basicUrl}/getProdById/${i}`);
  }
  
  searchProductByName(name:string,merchId:number):Observable<any> // Search By Name component
  {
    return this.http.get(`${this.basicUrl}/getProdByName/${name}/${merchId}`);
  }

  searchProductByCategory(cat:string,merchId:number):Observable<any> // Search By Category component
  {
    return this.http.get(`${this.basicUrl}/getProdByCategory/${cat}/${merchId}`);
  }

  searchProductByBrand(brand:string,merchId:number):Observable<any> // Search By Brand component
  {
    return this.http.get(`${this.basicUrl}/getProdByBrand/${brand}/${merchId}`);
  }

  getMerchantById(id: number):Observable<any>{
    console.log(this.currentMerchant);
    return this.http.get(`${this.basicUrl}/getAllProductsByMerchId/${id}`);
  }

  storeFeedback(feedback:FeedbackModel):Observable<any>{
    return this.http.post(`${this.basicUrl}/storeFeedback`,feedback);
  }

  getFeedbackByProductId(id:number):Observable<any>{
    return this.http.get(`${this.basicUrl}/getAllFeedback/${id}`);

  }

}
