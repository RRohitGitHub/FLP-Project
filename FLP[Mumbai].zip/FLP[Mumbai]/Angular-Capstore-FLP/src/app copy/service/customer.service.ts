import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';
import { CustomerModel } from '../customer.model';
import { MerchantModel } from '../merchant.model';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {
  url : string="http://localhost:9990/capstore";
  edit : number;
  customer: CustomerModel;
  merchant:MerchantModel;
  constructor(private http : HttpClient,private router : Router) { 
  }

  // CUSTOMER
  searchAllCustomers(): Observable<any>{
    
    return this.http.get(`${this.url}/findAllCustomers`);
  }

  updateCustomer(value: any): Observable<any>{
    console.log(value);
    return this.http.put(`${this.url}/updateCustomer/${this.edit}`, value);
  }

  searchById(index:number): Observable<any>{
    console.log(this.edit);
    return this.http.get(`${this.url}/findCustomerById/${this.edit}`);
  }

  delete(index:number):Observable<any>{
    return this.http.delete(`${this.url}/customer/delete/${index}`);
  }

  getall():Observable<any>{
    return this.http.get(`${this.url}/exists`);

  }

  authentication(username:String,password:String,value:any):Observable<any>{
    return this.http.put(`${this.url}/getdetails/${username}/${password}`,value);
   
  }

  saveDetails(capstore:CustomerModel):Observable<any>
  {
    return this.http.post(`${this.url}/customerAdd`,capstore);
  }

  //MERCHANT
  searchMerchantById(id:number): Observable<Object>{
    return this.http.get(`${this.url}/find/${id}`);
  }

  searchAllMerchants(): Observable<any>{
    return this.http.get(`${this.url}/findall`);
  }
  deleteMerchant(id:number): Observable<Object>{
    return this.http.delete(`${this.url}/delete/${id}`);
  }

  updateMerchant(id:number, crud : Object) : Observable<Object>{
    return this.http.put(`${this.url}/update/${id}`,crud);
  }
}
