import { TestBed } from '@angular/core/testing';

import { ProductHomePageService } from './product-home-page.service';

describe('ProductHomePageService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ProductHomePageService = TestBed.get(ProductHomePageService);
    expect(service).toBeTruthy();
  });
});
