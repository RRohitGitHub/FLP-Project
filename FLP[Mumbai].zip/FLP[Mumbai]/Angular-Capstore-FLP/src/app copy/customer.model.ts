export class CustomerModel
{
    public customerId:number;
    public customerName:string;
    public customerEmail:string;
    public customerPhone:string;
    public customerPassword:string;
    public customerAadhar:string;
    public customerAddress:string;
}
