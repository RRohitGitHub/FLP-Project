import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerShowDetailsComponent } from './customer-show-details.component';

describe('CustomerShowDetailsComponent', () => {
  let component: CustomerShowDetailsComponent;
  let fixture: ComponentFixture<CustomerShowDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CustomerShowDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerShowDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
