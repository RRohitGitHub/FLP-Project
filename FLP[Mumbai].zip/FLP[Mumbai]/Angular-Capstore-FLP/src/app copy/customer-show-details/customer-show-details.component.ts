import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customer-show-details',
  templateUrl: './customer-show-details.component.html',
  styleUrls: ['./customer-show-details.component.css']
})
export class CustomerShowDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
