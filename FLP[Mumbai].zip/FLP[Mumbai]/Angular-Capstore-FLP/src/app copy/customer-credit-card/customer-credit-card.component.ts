import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customer-credit-card',
  templateUrl: './customer-credit-card.component.html',
  styleUrls: ['./customer-credit-card.component.css']
})
export class CustomerCreditCardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
