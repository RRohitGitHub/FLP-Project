import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { SearchAllCustomersComponent } from './search-all-customers/search-all-customers.component';
import { MenuComponent } from './menu/menu.component';
import { UpdateCustomerComponent } from './update-customer/update-customer.component';
import {HttpClientModule} from '@angular/common/http';
import { CustomerRouterModule } from './customer-router/customer-router.module';
import { SearchCustomerByIdComponent } from './search-customer-by-id/search-customer-by-id.component';
import { LoginPageComponent } from './login-page/login-page.component';
import { AdminLoginPageComponent } from './admin-login-page/admin-login-page.component';
import { MerchantLoginPageComponent } from './merchant-login-page/merchant-login-page.component';
import { CustomerLoginPageComponent } from './customer-login-page/customer-login-page.component';
import { MerchantSignupPageComponent } from './merchant-signup-page/merchant-signup-page.component';
import { CustomerSignupComponent } from './customer-signup/customer-signup.component';
import { AdminFrontPageComponent } from './admin-front-page/admin-front-page.component';
import { SearchAllMerchantsComponent } from './search-all-merchants/search-all-merchants.component';
import { SearchMerchantByIdComponent } from './search-merchant-by-id/search-merchant-by-id.component';
import { UpdateMerchantComponent } from './update-merchant/update-merchant.component';
import { AddProductsComponent } from './add-products/add-products.component';
import { BusinessAnalysisComponent } from './business-analysis/business-analysis.component';
import { DisplayProductComponent } from './display-product/display-product.component';
import { EditProductMerchantComponent } from './edit-product-merchant/edit-product-merchant.component';
import { FeedbackComponent } from './feedback/feedback.component';
import { NavbarSearchComponent } from './navbar-search/navbar-search.component';
import { MerchantProfileComponent } from './merchant-profile/merchant-profile.component';
import { SearchProductMerchantComponent } from './search-product-merchant/search-product-merchant.component';
import { MerchantHomePageComponent } from './merchant-home-page/merchant-home-page.component';
import { CustomerCashOnDeliveryComponent } from './customer-cash-on-delivery/customer-cash-on-delivery.component';
import { CustomerDebitCardComponent } from './customer-debit-card/customer-debit-card.component';
import { CustomerCreditCardComponent } from './customer-credit-card/customer-credit-card.component';
import { CustomerHomePageComponent } from './customer-home-page/customer-home-page.component';
import { CustomerOrderedItemsComponent } from './customer-ordered-items/customer-ordered-items.component';
import { CustomerShowDetailsComponent } from './customer-show-details/customer-show-details.component';
import { CustomerInvoiceComponent } from './customer-invoice/customer-invoice.component';
import { CustomerPaymentComponent } from './customer-payment/customer-payment.component';
import { CustomerProfileComponent } from './customer-profile/customer-profile.component';
import { CustomerShoppingCartComponent } from './customer-shopping-cart/customer-shopping-cart.component';
import { CustomerShippingDetailsComponent } from './customer-shipping-details/customer-shipping-details.component';
import { SearchCustomerComponent } from './search-customer/search-customer.component';
import { CustomerUserComponent } from './customer-user/customer-user.component';
import { CustomerViewProductComponent } from './customer-view-product/customer-view-product.component';
import { CustomerWishlistComponent } from './customer-wishlist/customer-wishlist.component';
import { CustomerDeleteComponent } from './customer-delete/customer-delete.component';

@NgModule({
  declarations: [
    AppComponent,
    SearchAllCustomersComponent,
    MenuComponent,
    UpdateCustomerComponent,
    SearchCustomerByIdComponent,
    LoginPageComponent,
    AdminLoginPageComponent,
    MerchantLoginPageComponent,
    CustomerLoginPageComponent,
    MerchantSignupPageComponent,
    CustomerSignupComponent,
    AdminFrontPageComponent,
    SearchAllMerchantsComponent,
    SearchMerchantByIdComponent,
    UpdateMerchantComponent,
    AddProductsComponent,
    BusinessAnalysisComponent,
    DisplayProductComponent,
    EditProductMerchantComponent,
    FeedbackComponent,
    NavbarSearchComponent,
    MerchantProfileComponent,
    SearchProductMerchantComponent,
   
    MerchantHomePageComponent,
   
    CustomerCashOnDeliveryComponent,
   
    CustomerDebitCardComponent,
   
    CustomerCreditCardComponent,
   
    CustomerHomePageComponent,
   
    CustomerOrderedItemsComponent,
   
    CustomerShowDetailsComponent,
   
    CustomerInvoiceComponent,
   
    CustomerPaymentComponent,
   
    CustomerProfileComponent,
   
    CustomerShoppingCartComponent,
   
    CustomerShippingDetailsComponent,
   
    SearchCustomerComponent,
   
    CustomerUserComponent,
   
    CustomerViewProductComponent,
   
    CustomerWishlistComponent,
   
    CustomerDeleteComponent
  ],
  imports: [
    BrowserModule, FormsModule, HttpClientModule, CustomerRouterModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
