import { Component, OnInit } from '@angular/core';
import { ProductHomePageService } from '../service/product-home-page.service';
import { Route } from '@angular/compiler/src/core';
import { Router } from '@angular/router';
import { Product } from '../product.model';
import { LoginPageComponent } from '../login-page/login-page.component';

@Component({
  selector: 'app-display-product',
  templateUrl: './display-product.component.html',
  styleUrls: ['./display-product.component.css']
})
export class DisplayProductComponent implements OnInit {

  products: any[];
  product:any;
  flag:boolean;
  merchantId:number;

  constructor(private loginPage:LoginPageComponent,private service:ProductHomePageService,private router:Router) { 
    this.product=new Product();
    this.merchantId=this.service.currentMerchant.merchantId;
    

  }

  ngOnInit() {
    this.loginPage.hide=false;
    this.merchantId=this.service.currentMerchant.merchantId;
    this.service.getMerchantById(this.merchantId).subscribe(data=>{this.products=data,console.log(data),this.service.products=data},error=>{console.log(error)});

  }

  delete(i : number)
  {

    // for(let i=0;i<this.products.length;i++){
    //   this.service.storedetails(this.products[i]);
    //   console.log(this.products[i]);
    // }

    console.log(i);
    console.log(this.products[i].productId);
    var ans=confirm("Do you want to delete Product");
    if(ans==true){
      this.service.deleteProduct(this.products[i].productId,i).subscribe(data=>{this.flag=data,console.log(this.flag)},error=>{console.log(error)});
      //window.location.reload();
      //this.router.navigateByUrl('/merchant-home/merchant-display', {skipLocationChange: true}).then(()=>
      //this.router.navigate(["/merchant-home/merchant-display"])); 

    }else{
     
    }
   
 
    /* if(this.products.length==0)
    {
      this.flag=true;
    }
    else{
      this.flag=false;
    }*/
    // this.ngOnInit();
   // this.service.showProducts().subscribe(data=>{this.products=data,console.log(data)},error=>{console.log(error)});

  }

  edit(i:number)
  {
    this.service.editIndex =this.products[i].productId;
    
    this.router.navigate(['merchant-home/merchant-edit']);
    // this.service.editProduct(i);
  }

}
