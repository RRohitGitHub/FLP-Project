import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CustomerService } from '../service/customer.service';
import { MerchantModel } from '../merchant.model';
import { HttpClient } from '@angular/common/http';
import { ProductHomePageService } from '../service/product-home-page.service';

@Component({
  selector: 'merchant-login',
  templateUrl: './merchant-login-page.component.html',
  styleUrls: ['./merchant-login-page.component.css']
})
export class MerchantLoginPageComponent implements OnInit {
  emails:any[]=[];
  flag:boolean;
  passwords:any[]=[];
  login : any;
  merchant:any;
  invalidLogin : false;
  t:boolean;
  constructor(private merchantService:ProductHomePageService,private service:CustomerService, private router: Router, private http : HttpClient){
    this.login= new MerchantModel();
    this.http.get<any[]>('http://localhost:9990/capstore/exist')
    .subscribe(data => {this.emails=data,console.log(this.emails)}, error => console.log(error));
    this.http.get<any[]>('http://localhost:9990/capstore/exists')
    .subscribe(data => {this.passwords=data,console.log(this.passwords)}, error => console.log(error));
}

  ngOnInit() {
  }

  onSubmit() {
    for(let j=0;j<this.emails.length;j++){
      if(this.login.merchantEmail==this.emails[j])
        this.t=true;

   }
   if(this.t==true){
   for(let i=0;i<this.emails.length;i++)
       {if(this.login.merchantEmail==this.emails[i])
      {if(this.login.merchantPassword==this.passwords[i])
        {
          this.http.get<any>(`http://localhost:9990/capstore/getMerchant/${this.login.merchantEmail}`)
    .subscribe(data => {console.log(this.merchantService.currentMerchant),this.merchantService.currentMerchant=data}, error => console.log(error));
        
        this.router.navigate(['merchant-home']);
        }else
          alert("invalid");
      }
    }
   }
   else
   alert("Email ID not present!");
  }  
  
  signUp(){
    console.log("signed up");
    this.router.navigate(['merchant-signup']);
  }
}
