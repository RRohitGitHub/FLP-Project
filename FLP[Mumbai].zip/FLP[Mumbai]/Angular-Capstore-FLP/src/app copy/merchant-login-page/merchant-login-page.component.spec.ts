import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MerchantLoginPageComponent } from './merchant-login-page.component';

describe('MerchantLoginPageComponent', () => {
  let component: MerchantLoginPageComponent;
  let fixture: ComponentFixture<MerchantLoginPageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MerchantLoginPageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MerchantLoginPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
