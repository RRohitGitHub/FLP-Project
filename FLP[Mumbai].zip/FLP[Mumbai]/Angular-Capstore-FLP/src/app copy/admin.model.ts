export class AdminModel{
    username:string;
    password:string;

}