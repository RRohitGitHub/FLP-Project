import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchMerchantByIdComponent } from './search-merchant-by-id.component';

describe('SearchMerchantByIdComponent', () => {
  let component: SearchMerchantByIdComponent;
  let fixture: ComponentFixture<SearchMerchantByIdComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchMerchantByIdComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchMerchantByIdComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
