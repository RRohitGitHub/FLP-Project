import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customer-ordered-items',
  templateUrl: './customer-ordered-items.component.html',
  styleUrls: ['./customer-ordered-items.component.css']
})
export class CustomerOrderedItemsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
