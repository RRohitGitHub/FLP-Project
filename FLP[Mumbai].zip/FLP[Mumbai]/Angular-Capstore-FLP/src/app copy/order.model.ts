export class CustomerOrderBean{
    public orderId : number;
    public  proId :number;
    public proName : string;
    public  price :number;
    public orderDate : Date;
    public paymentMode : string;
}