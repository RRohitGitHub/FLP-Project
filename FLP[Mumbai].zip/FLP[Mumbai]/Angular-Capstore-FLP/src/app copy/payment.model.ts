export class Payment{
    public cardname : String;
    public accountNo : number;
    public expirydate : Date;
    public cvv : number;  
}