import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MerchantHomePageComponent } from './merchant-home-page.component';

describe('MerchantHomePageComponent', () => {
  let component: MerchantHomePageComponent;
  let fixture: ComponentFixture<MerchantHomePageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MerchantHomePageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MerchantHomePageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
