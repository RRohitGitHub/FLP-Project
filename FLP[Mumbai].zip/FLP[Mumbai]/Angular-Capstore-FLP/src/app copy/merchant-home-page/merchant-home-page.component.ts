import { Component, OnInit } from '@angular/core';
import { MerchantModel } from '../merchant.model';
import { ProductHomePageService } from '../service/product-home-page.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-merchant-home-page',
  templateUrl: './merchant-home-page.component.html',
  styleUrls: ['./merchant-home-page.component.css']
})
export class MerchantHomePageComponent implements OnInit {

  search:string;
  title = 'Merchant-HomePage';
  merchant : MerchantModel;


  constructor(private service:ProductHomePageService,private router:Router) { 
    this.merchant=new MerchantModel();
  }

  ngOnInit() {
    //this.router.navigate(['merchant-home/merchant-profile']);
  }

  
 /* addProduct(){
    this.router.navigate(['merchant-add']);
  }*/

  navsearch(){
    console.log(this.search);
    this.service.navBarSearch=this.search;
    this.router.navigate(['merchant-home/merchant-navs']);
  }

}
