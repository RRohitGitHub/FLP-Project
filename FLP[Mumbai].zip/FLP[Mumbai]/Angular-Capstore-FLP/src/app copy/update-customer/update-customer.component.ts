import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../service/customer.service';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { CustomerModel } from '../customer.model';

@Component({
  selector: 'update-customer',
  templateUrl: './update-customer.component.html',
  styleUrls: ['./update-customer.component.css']
})
export class UpdateCustomerComponent implements OnInit {
  customer : CustomerModel;
  hide : boolean;
  
  constructor(private service : CustomerService, private router : Router, private http : HttpClient) { 
    this.customer=new CustomerModel();
    this.service.searchById(this.customer.customerId)
    .subscribe(data => {this.customer=data, console.log(this.customer)}, error => console.log(error));   
    console.log(this.customer);
}

  ngOnInit() { 
  }

  updateCustomer(cust : CustomerModel){    
     this.service.updateCustomer(cust)
      .subscribe(data => {cust=data,console.log(cust)}, error => console.log(error));
      this.hide = true;
      this.router.navigate(['admin-front/list-customers']);
  }
}
