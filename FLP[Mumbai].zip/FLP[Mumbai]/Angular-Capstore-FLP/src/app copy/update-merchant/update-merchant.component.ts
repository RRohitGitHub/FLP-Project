import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../service/customer.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-update-merchant',
  templateUrl: './update-merchant.component.html',
  styleUrls: ['./update-merchant.component.css']
})
export class UpdateMerchantComponent implements OnInit {

  merchant: any;
  constructor(private service:CustomerService, private router:Router) { 
   this.merchant=this.service.merchant;
   console.log(this.merchant);
   this.service.searchMerchantById(this.merchant)
   .subscribe(data => {this.merchant= data, console.log(this.merchant)});
  }
                                                                                                                                                                                   
  ngOnInit() {
  }
  update(){
   this.service.updateMerchant(this.merchant.merchantId,this.merchant)
   .subscribe(data => {this.merchant= data, console.log(this.merchant)});
   this.router.navigate(['list-merchants']);
   }


}
