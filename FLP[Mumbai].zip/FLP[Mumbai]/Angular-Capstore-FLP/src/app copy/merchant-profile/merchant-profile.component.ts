import { Component, OnInit } from '@angular/core';
import { MerchantModel } from '../merchant.model';
import { CustomerService } from '../service/customer.service';
import { ProductHomePageService } from '../service/product-home-page.service';

@Component({
  selector: 'app-merchant-profile',
  templateUrl: './merchant-profile.component.html',
  styleUrls: ['./merchant-profile.component.css']
})
export class MerchantProfileComponent implements OnInit {
  merchant : MerchantModel;
  flag:boolean;
  constructor(private service:CustomerService,private merchantService:ProductHomePageService) {
   
  }

  ngOnInit() {
    this.merchant = this.merchantService.currentMerchant;
    this.flag=true;
  }
}
