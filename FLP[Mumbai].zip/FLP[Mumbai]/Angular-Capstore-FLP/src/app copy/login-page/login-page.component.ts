import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'login-page',
  templateUrl: './login-page.component.html',
  styleUrls: ['./login-page.component.css']
})
export class LoginPageComponent implements OnInit {
  hide:boolean;
  show:boolean;

  constructor(private router :Router) { }

  ngOnInit() {
    this.hide=true;
  }

  adminLogin(){
    this.hide=false;
    this.router.navigate(['admin-login']);
  }

  merchantLogin(){
    this.hide=false;
    this.router.navigate(['merchant-login']);
  }

  customerLogin(){
    this.hide=false;
    this.router.navigate(['customer-login']);
  }
}
