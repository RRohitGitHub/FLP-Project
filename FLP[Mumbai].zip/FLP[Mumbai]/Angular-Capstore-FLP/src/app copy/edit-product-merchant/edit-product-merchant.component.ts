import { Component, OnInit } from '@angular/core';
import { ProductHomePageService } from '../service/product-home-page.service';
import { Router } from '@angular/router';
import { Product } from '../product.model';

@Component({
  selector: 'app-edit-product-merchant',
  templateUrl: './edit-product-merchant.component.html',
  styleUrls: ['./edit-product-merchant.component.css']
})
export class EditProductMerchantComponent implements OnInit {

  product : any;
  categories : string[];
  subCategories : string[]=[];
  subElectronics : string[]
  subLifestyle : string[];


  constructor(private service : ProductHomePageService, private router : Router) {
    this.product = new Product();
    this.subElectronics=["","Mobiles","Laptops"];
    this.subLifestyle=["","Clothing","Footwear","Bag Packs","Miscellaneous"];
    this.product = new Product();

   }

  ngOnInit() {
    this.service.getProductById(this.service.editIndex).subscribe(data=>{this.product=data,console.log(this.product)},error=>{console.log(error)});

  }

  putSubCat(sc : string)
  {
    this.product.subCategory=sc;
  }

  fetchE(){
    this.subCategories=[];
    this.subCategories=this.subElectronics;
  }
  fetchL(){
    this.subCategories=[];
    this.subCategories=this.subLifestyle;
  }
  editProduct()
  {
    this.service.updateProduct(this.product).subscribe(data=>{this.product=data,console.log(this.product)},error=>{console.log(error)});
    this.router.navigate(['merchant-home/merchant-display']);
  }


}
