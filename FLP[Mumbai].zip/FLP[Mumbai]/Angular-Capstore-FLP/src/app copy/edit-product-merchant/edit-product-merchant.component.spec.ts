import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditProductMerchantComponent } from './edit-product-merchant.component';

describe('EditProductMerchantComponent', () => {
  let component: EditProductMerchantComponent;
  let fixture: ComponentFixture<EditProductMerchantComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditProductMerchantComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditProductMerchantComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
