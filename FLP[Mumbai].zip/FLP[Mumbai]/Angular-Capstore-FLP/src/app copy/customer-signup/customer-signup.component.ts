import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../service/customer.service';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { CustomerModel } from '../customer.model';

@Component({
  selector: 'app-customer-signup',
  templateUrl: './customer-signup.component.html',
  styleUrls: ['./customer-signup.component.css']
})
export class CustomerSignupComponent {

  capstore:any;
  existEmail:any[]=[];
  index:number;
  checkStatus:boolean;
  types:string[];
  flag:boolean;
 
  constructor(private http:HttpClient,private router : Router){
    this.capstore=new CustomerModel();
   
this.http.get<any[]>('http://localhost:9990/capstore/customerEmail')
.subscribe(data => {this.existEmail=data,console.log(this.existEmail)}, error => console.log(error));
  }
  add(){
   this.flag=true;
    this.check();
    this.http.post('http://localhost:9990/capstore/'+'customerAdd',this.capstore)
    .subscribe(data => {this.capstore=data,console.log(this.capstore)}, error => console.log(error)); 
  }
  check(){
    for( let index=0;index<this.existEmail.length;index++){
        if(this.existEmail[index]==this.capstore.customerEmail){
          this.flag=false;
          this.checkStatus=true;     
        }
    }
  }
 
  login(){
    this.router.navigate(['customer-login']);
  }
}
