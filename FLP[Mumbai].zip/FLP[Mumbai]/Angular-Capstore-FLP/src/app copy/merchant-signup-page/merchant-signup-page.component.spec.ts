import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MerchantSignupPageComponent } from './merchant-signup-page.component';

describe('MerchantSignupPageComponent', () => {
  let component: MerchantSignupPageComponent;
  let fixture: ComponentFixture<MerchantSignupPageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MerchantSignupPageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MerchantSignupPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
