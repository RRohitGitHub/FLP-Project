import { Product } from "./product.model";

    export class wishlist{
        public wishId:number;
        public cust_id:number;
        public product:Product;


}