import { Component, OnInit } from '@angular/core';
import { Product } from '../product.model';
import { ProductHomePageService } from '../service/product-home-page.service';
import * as CanvasJS from '../../app/business-analysis/dependency/canvasjs.min';

@Component({
  selector: 'app-business-analysis',
  templateUrl: './business-analysis.component.html',
  styleUrls: ['./business-analysis.component.css']
})
export class BusinessAnalysisComponent implements OnInit {

  products: any[]=[];

  product: Product;
	demo:Product;
	dps:any[]=[];
	dpsStock:any[]=[];
	dpsSold:any[]=[];
	yval:any;
	lname:any;



  constructor(private service:ProductHomePageService) { 
    this.product = new Product();
	  this.demo=new Product();
	  this.products = [];
  }

  ngOnInit() {
    this.service.getMerchantById(this.service.currentMerchant.merchantId)
		.subscribe(data => {this.products=data, console.log(this.products)} , error => console.log(error));
  }

  voteChart(){
		console.log(this.products[0]);
		this.dps=[];
		let chart = new CanvasJS.Chart("chartContainer", {
		animationEnabled: true,
		exportEnabled: true,
		title: {
			text: "Business Analysis"
		},
		data: [{
			type: "column",
			dataPoints:this.dps
		}]
	});
		for(let i=0;i<this.products.length;i++){
				this.yval=this.products[i].avgRating ;
				this.lname=this.products[i].productName;
				this.dps.push(
					{
						y:this.yval,
						label:this.lname
					}
				);
				
		}
	chart.render();
  }

  soldChart(){
		//this.show1();
		this.dpsSold=[];
		this.dpsStock=[];
		var chart1 = new CanvasJS.Chart("chartContainer", {
			exportEnabled: true,
			animationEnabled: true,
			title:{
				text: "Sold Products."
			}, 
			axisX: {
				title: "Products"
			},
			axisY: {
				title: "Stock-Units",
				titleFontColor: "#4F81BC",
				lineColor: "#4F81BC",
				labelFontColor: "#4F81BC",
				tickColor: "#4F81BC"
			},
			axisY2: {
				title: "Sold - Units",
				titleFontColor: "#C0504E",
				lineColor: "#C0504E",
				labelFontColor: "#C0504E",
				tickColor: "#C0504E"
			},
			toolTip: {
				shared: true
			},
			legend: {
				cursor: "pointer",
				//itemclick: toggleDataSeries
			},
			data: [{
				type: "column",
				name: "Total Stocks",
				showInLegend: true,      
				yValueFormatString: "#,##0.# Units",
				dataPoints: this.dpsStock
			},
			{
				type: "column",
				name: "Total Sold",
				axisYType: "secondary",
				showInLegend: true,
				yValueFormatString: "#,##0.# Units",
				dataPoints:this.dpsSold
			}]
		});
		
		
		// function toggleDataSeries(e) {
		// 	if (typeof (e.dataSeries.visible) === "undefined" || e.dataSeries.visible) {
		// 		e.dataSeries.visible = false;
		// 	} else {
		// 		e.dataSeries.visible = true;
		// 	}

			for(let i=0;i<this.products.length;i++){
				this.yval=this.products[i].stock;
				this.lname=this.products[i].productName;
				this.dpsStock.push(
					{
						label:this.lname,
						y:this.yval
						
					}
				);
			}

			for(let i=0;i<this.products.length;i++){
				this.yval=this.products[i].soldStock;
				this.lname=this.products[i].productName;
				this.dpsSold.push(
					{
						label:this.lname,
						y:this.yval
						
					}
				);
			}


	chart1.render();		
	}


}
