import { Component, OnInit } from '@angular/core';
import { ProductHomePageService } from '../service/product-home-page.service';

@Component({
  selector: 'app-navbar-search',
  templateUrl: './navbar-search.component.html',
  styleUrls: ['./navbar-search.component.css']
})
export class NavbarSearchComponent implements OnInit {

  products:any[];
  flag:boolean;
  merchantId:number;
  constructor(private service:ProductHomePageService) {
    this.merchantId=this.service.currentMerchant.merchantId;
   }

  ngOnInit() {
    this.flag=true;
    this.service.searchProductByName(this.service.navBarSearch,this.merchantId).subscribe(data=>{this.products=data,console.log(this.products)},error=>{console.log(error)});

  }

}
