import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customer-user',
  templateUrl: './customer-user.component.html',
  styleUrls: ['./customer-user.component.css']
})
export class CustomerUserComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
