import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AdminModel } from '../admin.model';

@Component({
  selector: 'app-admin-login-page',
  templateUrl: './admin-login-page.component.html',
  styleUrls: ['./admin-login-page.component.css']
})
export class AdminLoginPageComponent implements OnInit {
  admin:AdminModel;
  status:boolean;
  hide:boolean;
  constructor(private router : Router) { 
    this.admin=new AdminModel();
  }

  ngOnInit() {
  }

  login(){
    if(this.admin.username =='admin@capstore.com' && this.admin.password=='Admin@123'){
      this.hide=true;
      this.router.navigate(['admin-front']);
    }
    else
      this.status=true;
  }
}
