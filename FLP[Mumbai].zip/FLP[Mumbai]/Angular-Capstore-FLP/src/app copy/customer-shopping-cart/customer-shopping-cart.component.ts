import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customer-shopping-cart',
  templateUrl: './customer-shopping-cart.component.html',
  styleUrls: ['./customer-shopping-cart.component.css']
})
export class CustomerShoppingCartComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
