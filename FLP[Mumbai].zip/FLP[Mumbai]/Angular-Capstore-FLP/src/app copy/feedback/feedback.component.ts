import { Component, OnInit } from '@angular/core';
import { FeedbackModel } from '../feedback.model';
import { ProductHomePageService } from '../service/product-home-page.service';

@Component({
  selector: 'app-feedback',
  templateUrl: './feedback.component.html',
  styleUrls: ['./feedback.component.css']
})
export class FeedbackComponent implements OnInit {

  ratingFeedback:FeedbackModel;
  rating:number[]=[];
  feedbacks:any[]=[];
  prodId:number;
  flag:boolean=false;

  constructor(private service:ProductHomePageService) {
    this.ratingFeedback = new FeedbackModel();
    this.feedbacks[0]=new FeedbackModel();
    this.ratingFeedback.prodId = 707;
    this.rating = [1,2,3,4,5];
  }

  ngOnInit() {
  }

  search(){
    this.flag=true;
    this.service.getFeedbackByProductId(this.prodId).subscribe(data=>{this.feedbacks=data,console.log(this.feedbacks)},error=>{console.log(error)});
  }

  // submitFeedback(){
  //   this.service.storeFeedback(this.ratingFeedback).subscribe(data=>{console.log(data)},error=>{console.log(error)});
  // }
}
