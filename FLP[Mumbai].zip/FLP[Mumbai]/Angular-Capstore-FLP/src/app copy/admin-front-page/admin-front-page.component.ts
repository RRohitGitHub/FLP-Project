import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'admin-front',
  templateUrl: './admin-front-page.component.html',
  styleUrls: ['./admin-front-page.component.css']
})
export class AdminFrontPageComponent implements OnInit {

  constructor(private router : Router) { }

  ngOnInit() {
  }

}
