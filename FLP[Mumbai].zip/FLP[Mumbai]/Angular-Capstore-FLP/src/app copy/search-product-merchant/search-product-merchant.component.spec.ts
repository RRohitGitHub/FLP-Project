import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchProductMerchantComponent } from './search-product-merchant.component';

describe('SearchProductMerchantComponent', () => {
  let component: SearchProductMerchantComponent;
  let fixture: ComponentFixture<SearchProductMerchantComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchProductMerchantComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchProductMerchantComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
