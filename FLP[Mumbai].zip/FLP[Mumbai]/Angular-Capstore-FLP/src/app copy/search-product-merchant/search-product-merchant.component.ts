import { Component, OnInit } from '@angular/core';
import { ProductHomePageService } from '../service/product-home-page.service';

@Component({
  selector: 'app-search-product-merchant',
  templateUrl: './search-product-merchant.component.html',
  styleUrls: ['./search-product-merchant.component.css']
})
export class SearchProductMerchantComponent implements OnInit {
  products : any[];
  search : string;
  textSearch:string;
  flag : boolean;
  merchantId:number;
  constructor(private service:ProductHomePageService) { 
    this.products=[];
    this.merchantId = this.service.currentMerchant.merchantId;
  }

  ngOnInit() {
  }

  
  name()
  {
    this.search="name";
  }
  brand()
  {
    this.search="brand";
  }
  category()
  {
    this.search="category";
  }

  searchBy()
  {
    //this.products.splice(0);
    if(this.search==="name")
    {
      this.flag=true;
       this.service.searchProductByName(this.textSearch,this.merchantId).subscribe(data=>{this.products=data,console.log(this.products)},error=>{console.log(error)});
    }
    if(this.search==="brand")
    {
      this.flag=true;
    this.service.searchProductByBrand(this.textSearch,this.merchantId).subscribe(data=>{this.products=data,console.log(this.products)},error=>{console.log(error)});
    }
    if(this.search==="category")
    {
      this.flag=true;
      this.service.searchProductByCategory(this.textSearch,this.merchantId).subscribe(data=>{this.products=data,console.log(this.products)},error=>{console.log(error)});
    }
    if(this.products.length!=0)
    {
      this.flag=true;
    }
    
  }
  

}
