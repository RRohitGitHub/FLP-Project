import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customer-wishlist',
  templateUrl: './customer-wishlist.component.html',
  styleUrls: ['./customer-wishlist.component.css']
})
export class CustomerWishlistComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
