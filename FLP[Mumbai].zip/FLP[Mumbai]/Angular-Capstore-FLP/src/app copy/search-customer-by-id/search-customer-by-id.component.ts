import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../service/customer.service';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { CustomerModel } from '../customer.model';

@Component({
  selector: 'search-customer-id',
  templateUrl: './search-customer-by-id.component.html',
  styleUrls: ['./search-customer-by-id.component.css']
})
export class SearchCustomerByIdComponent implements OnInit {
  customer : any;
  flag:boolean;
  constructor(private service : CustomerService,private router : Router, private http : HttpClient) {
    this.customer=new CustomerModel();
   }

  ngOnInit() {
  }

  searchById(index:number){
    // this.service.searchById(index)
    // .subscribe(data=> {this.customer=data},error =>console.log(error));
    
    this.http.get(`http://localhost:9990/capstore/findCustomerById/${index}`)
    .subscribe(data=> {this.customer=data, console.log(this.customer)},error =>console.log(error));
    this.service.customer=this.customer;
    if(index!=this.customer.customerId)
      alert("No customer found!!!");
    else
      this.flag=true;
  }

  deleteById(index : number){
    var con = confirm("Are you sure you want to delete?");
    if(con){
    this.service.delete(this.customer.customerId)
    .subscribe(data=> {this.customer=data},error => console.log(error));
    this.router.navigate(['admin-front/list-customers']);
    this.customer=new CustomerModel();
    window.location.reload();
    }
  }

  updateById(index : number){
    // localStorage.setItem("editUserId", index.toString());
    this.service.edit=index;
    var con = confirm("Are you sure you want to edit?");
    if(con){
      this.router.navigate(['admin-front/update-customer']);
    }
    else if(this.service.searchById(index)==null)
      alert("No record found for the id " + index);
  }
}
