import { Component, OnInit } from '@angular/core';
import { ProductHomePageService } from '../service/product-home-page.service';
import { Product } from '../product.model';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-products',
  templateUrl: './add-products.component.html',
  styleUrls: ['./add-products.component.css']
})
export class AddProductsComponent implements OnInit {

  product : any;

  categories : string[];
  subCategories : string[]=[];
  subElectronics : string[]
  subLifestyle : string[];


  constructor(private service : ProductHomePageService,private router:Router) {
    this.product = new Product();
    this.subElectronics=["","Mobiles","Laptops"];
    this.subLifestyle=["","Clothing","Footwear","Bag Packs","Miscellaneous"];
    this.product.merchantId = this.service.currentMerchant.merchantId;
    console.log(this.product.merchantId);
   }

  ngOnInit() {
  }

  putSubCat(sc : string)
  {
    this.product.subCategory=sc;
  }

  fetchE(){
    this.subCategories=[];
    this.subCategories=this.subElectronics;
  }
  fetchL(){
    this.subCategories=[];
    this.subCategories=this.subLifestyle;
  }

  addProduct()
  {
    console.log(this.product.productName);
    this.service.addProduct(this.product).subscribe(data=>{this.product=data,console.log(data)},error=>{console.log(error)});
    this.product = new Product();
    this.router.navigate(['merchant-home/merchant-display']);
  }


}
