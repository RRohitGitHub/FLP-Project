import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customer-view-product',
  templateUrl: './customer-view-product.component.html',
  styleUrls: ['./customer-view-product.component.css']
})
export class CustomerViewProductComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
