import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerShippingDetailsComponent } from './customer-shipping-details.component';

describe('CustomerShippingDetailsComponent', () => {
  let component: CustomerShippingDetailsComponent;
  let fixture: ComponentFixture<CustomerShippingDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CustomerShippingDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerShippingDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
