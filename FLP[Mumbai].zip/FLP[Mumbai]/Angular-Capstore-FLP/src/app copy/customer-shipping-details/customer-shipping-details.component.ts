import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customer-shipping-details',
  templateUrl: './customer-shipping-details.component.html',
  styleUrls: ['./customer-shipping-details.component.css']
})
export class CustomerShippingDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
