import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customer-cash-on-delivery',
  templateUrl: './customer-cash-on-delivery.component.html',
  styleUrls: ['./customer-cash-on-delivery.component.css']
})
export class CustomerCashOnDeliveryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
