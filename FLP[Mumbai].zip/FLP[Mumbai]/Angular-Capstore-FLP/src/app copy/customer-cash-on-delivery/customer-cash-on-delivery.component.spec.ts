import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerCashOnDeliveryComponent } from './customer-cash-on-delivery.component';

describe('CustomerCashOnDeliveryComponent', () => {
  let component: CustomerCashOnDeliveryComponent;
  let fixture: ComponentFixture<CustomerCashOnDeliveryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CustomerCashOnDeliveryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerCashOnDeliveryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
